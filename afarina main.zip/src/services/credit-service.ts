'use server';

import { getAuth } from 'firebase/auth/node';
import { getFirestore, doc, getDoc, updateDoc, serverTimestamp, FieldValue, increment } from 'firebase/firestore';
import { initializeFirebase } from '@/firebase';

const { firebaseApp } = initializeFirebase();
const firestore = getFirestore(firebaseApp);
const auth = getAuth(firebaseApp);

async function getCurrentUserId(): Promise<string> {
    // This is a simplified way to get the user on the server.
    // In a real app, you would get the user from the session or a verified token.
    const user = auth.currentUser;
    if (!user) {
        throw new Error('User not authenticated. Cannot manage credits.');
    }
    return user.uid;
}

/**
 * Checks if the user's monthly credits need to be reset and does so if necessary.
 * This should be called before any credit deduction.
 */
export async function checkAndResetCredits(): Promise<void> {
  const userId = await getCurrentUserId();
  const userDocRef = doc(firestore, 'users', userId);
  const userDoc = await getDoc(userDocRef);

  if (!userDoc.exists()) {
    throw new Error('User profile not found.');
  }

  const userData = userDoc.data();
  const lastReset = userData.lastCreditReset?.toDate();
  const now = new Date();

  // If lastCreditReset doesn't exist or if it's from a previous month
  if (!lastReset || lastReset.getMonth() !== now.getMonth() || lastReset.getFullYear() !== now.getFullYear()) {
    await updateDoc(userDocRef, {
      credits: 100, // Reset to the monthly free amount
      lastCreditReset: serverTimestamp(),
    });
  }
}


/**
 * Deducts a specified amount of credits from the current user's account.
 * @param amount The number of credits to deduct.
 * @throws An error if the user has insufficient credits.
 */
export async function deductCredits(amount: number): Promise<void> {
  await checkAndResetCredits(); // Ensure credits are up-to-date before deducting

  const userId = await getCurrentUserId();
  const userDocRef = doc(firestore, 'users', userId);
  const userDoc = await getDoc(userDocRef);

  if (!userDoc.exists() || userDoc.data().credits < amount) {
    throw new Error('Insufficient credits.');
  }

  await updateDoc(userDocRef, {
    credits: increment(-amount),
  });
}

/**
 * Adds a specified amount of credits to the current user's account.
 * @param amount The number of credits to add.
 */
export async function addCredits(amount: number): Promise<void> {
  const userId = await getCurrentUserId();
  const userDocRef = doc(firestore, 'users', userId);

  await updateDoc(userDocRef, {
    credits: increment(amount),
  });
}

/**
 * Retrieves the current credit balance for the authenticated user.
 * @returns The user's current credit balance.
 */
export async function getUserCredits(): Promise<number> {
    await checkAndResetCredits(); // Ensure credits are up-to-date before fetching
    const userId = await getCurrentUserId();
    const userDocRef = doc(firestore, 'users', userId);
    const userDoc = await getDoc(userDocRef);

    if (!userDoc.exists()) {
        throw new Error('User profile not found.');
    }

    return userDoc.data().credits || 0;
}
