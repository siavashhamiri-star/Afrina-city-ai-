
// Follow this format for your firebase config object
/*
export const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "your-app.firebaseapp.com",
  projectId: "your-app",
  storageBucket: "your-app.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcde12345"
};
*/
// This file will be replaced with the real config when you connect to Firebase.
export const firebaseConfig = {"apiKey":"API_KEY","authDomain":"fir-studio-7a71f.firebaseapp.com","projectId":"fir-studio-7a71f","storageBucket":"fir-studio-7a71f.appspot.com","messagingSenderId":"492476535102","appId":"1:492476535102:web:a6164d13540d6f22c53f7c"};
