'use server';

/**
 * @fileOverview This file defines the stateful Genkit flow for a simple word guessing game.
 *
 * It exports:
 * - `wordGameFlow`: A stateful flow that manages the game's state across turns.
 *
 * This flow uses a state object (`GameState`) that is maintained across invocations of the flow for the same user session (conceptually).
 * Note: In a real multi-user environment, you would need a mechanism to store and retrieve state for each user,
 * likely using a database and passing a session/user ID to the flow. For this example, we use a simple in-memory object
 * which will reset on server restart.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const words = ['apple', 'banana', 'cherry', 'orange', 'grape', 'lemon', 'melon', 'peach', 'pear', 'plum'];

// This is a simple in-memory state. In a real app, you'd use a database (like Firestore)
// keyed by a session or user ID to manage state for multiple users.
let gameState = {
  word: '',
  guesses: [] as string[],
  maxAttempts: 6,
};

const GameStateSchema = z.object({
    maskedWord: z.string().describe("The current state of the word, with unguessed letters masked."),
    guesses: z.array(z.string()).describe("The letters that have been guessed so far."),
    remainingAttempts: z.number().describe("How many attempts are left."),
    message: z.string().describe("A message to the user about the result of their guess."),
});

const WordGameInputSchema = z.object({
  action: z.enum(['start', 'guess', 'status']).describe("The action to perform."),
  guess: z.string().optional().describe("The letter or word being guessed."),
});

function getMaskedWord() {
  if (!gameState.word) return '';
  return gameState.word
    .split('')
    .map(letter => (gameState.guesses.includes(letter) ? letter : '_'))
    .join(' ');
}

function checkWin() {
    return gameState.word.split('').every(letter => gameState.guesses.includes(letter));
}


export const wordGameFlow = ai.defineFlow(
  {
    name: 'wordGameFlow',
    inputSchema: WordGameInputSchema,
    outputSchema: GameStateSchema,
  },
  async ({ action, guess }) => {

    if (action === 'start') {
      gameState.word = words[Math.floor(Math.random() * words.length)];
      gameState.guesses = [];
      gameState.maxAttempts = 6;
      return {
        maskedWord: getMaskedWord(),
        guesses: gameState.guesses,
        remainingAttempts: gameState.maxAttempts,
        message: "I've thought of a fruit. It has " + gameState.word.length + " letters. Try to guess a letter!",
      };
    }
    
    if (action === 'status') {
      return {
        maskedWord: getMaskedWord(),
        guesses: gameState.guesses,
        remainingAttempts: gameState.maxAttempts - gameState.guesses.filter(g => !gameState.word.includes(g)).length,
        message: "Here's the current status of the game."
      };
    }

    if (action === 'guess') {
      if (!gameState.word) {
        return {
            maskedWord: '',
            guesses: [],
            remainingAttempts: 0,
            message: "The game hasn't started yet! Say 'let's play a game' to begin.",
        }
      }

      const letter = (guess || '').toLowerCase().trim();
      if (!letter || letter.length !== 1) {
        return {
            maskedWord: getMaskedWord(),
            guesses: gameState.guesses,
            remainingAttempts: gameState.maxAttempts - gameState.guesses.filter(g => !gameState.word.includes(g)).length,
            message: "That wasn't a valid guess. Please guess a single letter.",
        }
      }

      if (gameState.guesses.includes(letter)) {
         return {
            maskedWord: getMaskedWord(),
            guesses: gameState.guesses,
            remainingAttempts: gameState.maxAttempts - gameState.guesses.filter(g => !gameState.word.includes(g)).length,
            message: `You already guessed '${letter}'. Try another one.`,
        }
      }
      
      gameState.guesses.push(letter);
      
      const remainingAttempts = gameState.maxAttempts - gameState.guesses.filter(g => !gameState.word.includes(g)).length;

      if (checkWin()) {
         const winningWord = gameState.word;
         gameState.word = ''; // Reset for next game
         return {
            maskedWord: winningWord,
            guesses: gameState.guesses,
            remainingAttempts: remainingAttempts,
            message: `You got it! The word was '${winningWord}'. Congratulations! We can play again anytime.`,
         }
      }

      if (remainingAttempts <= 0) {
        const losingWord = gameState.word;
        gameState.word = ''; // Reset for next game
        return {
            maskedWord: losingWord,
            guesses: gameState.guesses,
            remainingAttempts: 0,
            message: `Oh, it looks like you're out of attempts. The word was '${losingWord}'. Better luck next time! We can play again if you like.`
        }
      }
      
      let message = '';
      if(gameState.word.includes(letter)) {
          message = `Good guess! '${letter}' is in the word.`
      } else {
          message = `Sorry, '${letter}' is not in the word.`
      }

      return {
        maskedWord: getMaskedWord(),
        guesses: gameState.guesses,
        remainingAttempts: remainingAttempts,
        message: message,
      };
    }

    // Default case if no action matches
    return {
        maskedWord: getMaskedWord(),
        guesses: gameState.guesses,
        remainingAttempts: gameState.maxAttempts - gameState.guesses.filter(g => !gameState.word.includes(g)).length,
        message: "I'm not sure what you mean. We can chat, or play a word game."
    }
  }
);
