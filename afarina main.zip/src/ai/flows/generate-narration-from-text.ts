'use server';

/**
 * @fileOverview Converts text into speech using a Genkit flow.
 *
 * - generateNarrationFromText - A function that takes text and returns audio.
 * - GenerateNarrationFromTextInput - The input type for the function.
 * - GenerateNarrationFromTextOutput - The output type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import wav from 'wav';

const GenerateNarrationFromTextInputSchema = z.object({
  text: z.string().describe('The text to be converted to speech.'),
  voice: z.string().optional().describe('The voice to use for the narration.'),
});
export type GenerateNarrationFromTextInput = z.infer<typeof GenerateNarrationFromTextInputSchema>;

const GenerateNarrationFromTextOutputSchema = z.object({
  audioDataUri: z.string().describe('The generated audio as a data URI.'),
});
export type GenerateNarrationFromTextOutput = z.infer<typeof GenerateNarrationFromTextOutputSchema>;

export async function generateNarrationFromText(input: GenerateNarrationFromTextInput): Promise<GenerateNarrationFromTextOutput> {
  return generateNarrationFromTextFlow(input);
}

async function toWav(pcmData: Buffer, channels = 1, rate = 24000, sampleWidth = 2): Promise<string> {
  return new Promise((resolve, reject) => {
    const writer = new wav.Writer({
      channels,
      sampleRate: rate,
      bitDepth: sampleWidth * 8,
    });

    let bufs = [] as any[];
    writer.on('error', reject);
    writer.on('data', function (d) {
      bufs.push(d);
    });
    writer.on('end', function () {
      resolve(Buffer.concat(bufs).toString('base64'));
    });

    writer.write(pcmData);
    writer.end();
  });
}

const generateNarrationFromTextFlow = ai.defineFlow(
  {
    name: 'generateNarrationFromTextFlow',
    inputSchema: GenerateNarrationFromTextInputSchema,
    outputSchema: GenerateNarrationFromTextOutputSchema,
  },
  async input => {
    const {media} = await ai.generate({
      model: 'googleai/gemini-2.5-flash-preview-tts',
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {voiceName: input.voice || 'Algenib'},
          },
        },
      },
      prompt: input.text,
    });
    if (!media) {
      throw new Error('no media returned');
    }
    const audioBuffer = Buffer.from(media.url.substring(media.url.indexOf(',') + 1), 'base64');
    const wavBase64 = await toWav(audioBuffer);

    return {audioDataUri: 'data:audio/wav;base64,' + wavBase64};
  }
);
