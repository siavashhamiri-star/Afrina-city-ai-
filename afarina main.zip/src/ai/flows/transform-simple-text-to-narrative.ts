'use server';

/**
 * @fileOverview Transforms a simple text idea into a compelling narrative, script, or story.
 *
 * - transformSimpleTextToNarrative - A function that takes a simple text idea and expands it into a more compelling narrative.
 * - TransformSimpleTextToNarrativeInput - The input type for the transformSimpleTextToNarrative function.
 * - TransformSimpleTextToNarrativeOutput - The return type for the transformSimpleTextToNarrative function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const TransformSimpleTextToNarrativeInputSchema = z.object({
  simpleText: z.string().describe('A simple text idea or story prompt.'),
});
export type TransformSimpleTextToNarrativeInput = z.infer<typeof TransformSimpleTextToNarrativeInputSchema>;

const TransformSimpleTextToNarrativeOutputSchema = z.object({
  enhancedNarrative: z.string().describe('The enhanced narrative, script, or story.'),
});
export type TransformSimpleTextToNarrativeOutput = z.infer<typeof TransformSimpleTextToNarrativeOutputSchema>;

export async function transformSimpleTextToNarrative(input: TransformSimpleTextToNarrativeInput): Promise<TransformSimpleTextToNarrativeOutput> {
  return transformSimpleTextToNarrativeFlow(input);
}

const prompt = ai.definePrompt({
  name: 'transformSimpleTextToNarrativePrompt',
  input: {schema: TransformSimpleTextToNarrativeInputSchema},
  output: {schema: TransformSimpleTextToNarrativeOutputSchema},
  prompt: `You are an expert story writer. Given a simple text idea, expand it into a compelling narrative, script, or story.\n\nSimple Text Idea: {{{simpleText}}}`,
});

const transformSimpleTextToNarrativeFlow = ai.defineFlow(
  {
    name: 'transformSimpleTextToNarrativeFlow',
    inputSchema: TransformSimpleTextToNarrativeInputSchema,
    outputSchema: TransformSimpleTextToNarrativeOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
