'use server';

/**
 * @fileOverview Generates an animated music video based on a song and description.
 *
 * - generateAnimatedMusicVideo - A function that handles the animated music video generation process.
 * - GenerateAnimatedMusicVideoInput - The input type for the generateAnimatedMusicVideo function.
 * - GenerateAnimatedMusicVideoOutput - The return type for the generateAnimatedMusicVideo function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import * as fs from 'fs';
import {Readable} from 'stream';

const GenerateAnimatedMusicVideoInputSchema = z.object({
  musicDataUri: z
    .string()
    .describe(
      'The music track as a data URI that must include a MIME type and use Base64 encoding. Expected format: \'data:<mimetype>;base64,<encoded_data>\'.' // Updated description
    ),
  visualStyleDescription: z.string().describe('Description of the desired visual style for the animated music video.'),
  imageStyleDescription: z.string().optional().describe('Optional description of the image style.'),
  imageUri: z
    .string()
    .optional()
    .describe(
      'An optional image used for reference in the animation, as a data URI that must include a MIME type and use Base64 encoding. Expected format: \'data:<mimetype>;base64,<encoded_data>\'.' // Updated description
    ),
});
export type GenerateAnimatedMusicVideoInput = z.infer<typeof GenerateAnimatedMusicVideoInputSchema>;

const GenerateAnimatedMusicVideoOutputSchema = z.object({
  videoDataUri: z.string().describe('The generated animated music video as a data URI (MP4 format).'),
});
export type GenerateAnimatedMusicVideoOutput = z.infer<typeof GenerateAnimatedMusicVideoOutputSchema>;

export async function generateAnimatedMusicVideo(
  input: GenerateAnimatedMusicVideoInput
): Promise<GenerateAnimatedMusicVideoOutput> {
  return generateAnimatedMusicVideoFlow(input);
}

const generateAnimatedMusicVideoPrompt = ai.definePrompt({
  name: 'generateAnimatedMusicVideoPrompt',
  input: {schema: GenerateAnimatedMusicVideoInputSchema},
  output: {schema: GenerateAnimatedMusicVideoOutputSchema},
  prompt: `You are an AI video generator specializing in creating short animated music videos.

  The user will provide a music track and a description of the desired visual style.
  Optionally, the user may also provide an image and description of the image style to use.

  Create a short animated music video (around 10-15 seconds) that matches the music and the described visual style.

  Music track: {{media url=musicDataUri}}
  Visual style description: {{{visualStyleDescription}}}
  {{#if imageUri}}
  Image style description: {{{imageStyleDescription}}}
  Image: {{media url=imageUri}}
  {{/if}}`,
});

const generateAnimatedMusicVideoFlow = ai.defineFlow(
  {
    name: 'generateAnimatedMusicVideoFlow',
    inputSchema: GenerateAnimatedMusicVideoInputSchema,
    outputSchema: GenerateAnimatedMusicVideoOutputSchema,
  },
  async input => {
    let operation = await ai.generate({
      model: 'veo-2.0-generate-001',
      prompt: [
        {
          text: input.visualStyleDescription,
        },
        {
          media: {url: input.musicDataUri},
        },
        ...(input.imageUri
          ? [
              {
                text: input.imageStyleDescription || 'Use the style of this image',
              },
              {
                media: {url: input.imageUri},
              },
            ]
          : []),
      ],
      config: {
        durationSeconds: 10,
        aspectRatio: '16:9',
        personGeneration: 'allow_adult',
      },
    });
    if (!operation) {
      throw new Error('Expected the model to return an operation');
    }

    // Wait until the operation completes. Note that this may take some time, maybe even up to a minute. Design the UI accordingly.
    while (!operation.done) {
      operation = await ai.checkOperation(operation);
      // Sleep for 5 seconds before checking again.
      await new Promise(resolve => setTimeout(resolve, 5000));
    }

    if (operation.error) {
      throw new Error('failed to generate video: ' + operation.error.message);
    }

    const video = operation.output?.message?.content.find(p => !!p.media);
    if (!video) {
      throw new Error('Failed to find the generated video');
    }
    return {videoDataUri: video.media!.url!};
  }
);
