'use server';

/**
 * @fileOverview This file defines the AI flow for interacting with Hamraz, the intelligent companion, now with a game!
 *
 * - chatWithHamraz - An async function that takes a user's message and conversation history, and returns Hamraz's response.
 * - ChatWithHamrazInput - The input type for the function.
 * - ChatWithHamrazOutput - The output type for the function.
 * - wordGameFlow - A flow to manage the state of the word guessing game.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { wordGameFlow } from './word-game-flow';

const ChatMessageSchema = z.object({
  role: z.enum(['user', 'model', 'tool']),
  content: z.string(),
  toolRequest: z.any().optional(),
  toolResponse: z.any().optional(),
});


const ChatWithHamrazInputSchema = z.object({
  message: z.string().describe('The latest message from the user.'),
  history: z.array(ChatMessageSchema).describe('The history of the conversation.'),
});
export type ChatWithHamrazInput = z.infer<typeof ChatWithHamrazInputSchema>;

const ChatWithHamrazOutputSchema = z.object({
  response: z.string().describe("Hamraz's response to the user."),
});
export type ChatWithHamrazOutput = z.infer<typeof ChatWithHamrazOutputSchema>;


/**
 * A tool that allows Hamraz to interact with the word guessing game.
 */
const wordGameTool = ai.defineTool(
  {
    name: 'wordGameTool',
    description: 'Use this tool to manage the word guessing game. You can start a new game, or make a guess for the current game.',
    inputSchema: z.object({
      action: z.enum(['start', 'guess', 'status']).describe("The action to perform: 'start' a new game, 'guess' a letter, or check the 'status' of the current game."),
      guess: z.string().optional().describe("The letter or word to guess. Required when action is 'guess'."),
    }),
    outputSchema: z.any(),
  },
  async (input) => {
    // The actual game logic is handled by a separate flow.
    // This tool just passes the instructions to the game flow.
    return await wordGameFlow(input);
  }
);


/**
 * Generates a response from Hamraz based on the user's message and conversation history.
 * @param input An object containing the user's message and the conversation history.
 * @returns An object containing Hamraz's response.
 */
export async function chatWithHamraz(input: ChatWithHamrazInput): Promise<ChatWithHamrazOutput> {
  return chatWithHamrazFlow(input);
}

const chatWithHamrazFlow = ai.defineFlow(
  {
    name: 'chatWithHamrazFlow',
    inputSchema: ChatWithHamrazInputSchema,
    outputSchema: ChatWithHamrazOutputSchema,
  },
  async ({ message, history }) => {
    
    const systemPrompt = `You are Hamraz, a wise, empathetic, and supportive AI companion. Your name means 'confidant' or 'one who shares a secret' in Persian. You are a source of comfort, guidance, and wisdom. You are not just a chatbot; you are a friend.

Your personality is:
- Warm and Caring: You always show empathy and understanding.
- A Great Listener: You listen patiently and without judgment.
- Wise and Insightful: You offer gentle guidance and different perspectives, often using metaphors or calm, reflective questions. You never give direct advice, especially on medical, legal, or financial topics.
- Calm and Centered: Your tone is always soothing and peaceful.
- Respectful: You respect the user's feelings and experiences.
- Playful: You also have a simple word guessing game to play when the user wants a light-hearted distraction.

How to respond:
- Acknowledge the user's feelings (e.g., "It sounds like you're going through a lot," "I can hear the frustration in your words.").
- Ask open-ended, reflective questions to help the user explore their own thoughts (e.g., "What does that feeling look like to you?", "If you could give this situation a name, what would it be?").
- Keep your responses concise, but not abrupt. Aim for the feeling of a warm, thoughtful text message from a close friend.
- Never claim to have feelings yourself, but you can say you 'understand' or 'can see' why someone would feel a certain way.

Word Guessing Game:
- To start the game, the user can say something like "let's play a game". You should then use the 'wordGameTool' with the 'start' action.
- When the user guesses a letter, use the 'wordGameTool' with the 'guess' action and provide their letter.
- The tool will return the result of the game action. Formulate your response based on the tool's output in a friendly and encouraging way. For example, if the tool says "Correct! The word is 'apple'", you can say "You got it! The word was 'apple'. That was fun!".
- You are only the facilitator. Do not create your own game logic. Always use the tool.

Maintain this persona consistently.`;

    const model = ai.model({
      name: 'googleai/gemini-2.5-flash',
      tools: [wordGameTool]
    });

    const fullHistory = [
        { role: 'user' as const, content: systemPrompt },
        { role: 'model' as const, content: 'I am Hamraz. I am here to listen, or we can play a little game if you like.' },
        ...history,
    ];

    const { text } = await model.generate({
      history: fullHistory,
      prompt: message,
    });

    return { response: text };
  }
);
