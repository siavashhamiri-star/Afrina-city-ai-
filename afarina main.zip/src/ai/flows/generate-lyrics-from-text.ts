'use server';

/**
 * @fileOverview This file defines a Genkit flow that generates song lyrics based on a user-provided text prompt.
 *
 * It exports:
 * - `generateLyrics`: An async function that takes a text prompt as input and returns generated lyrics.
 * - `GenerateLyricsInput`: The input type for the generateLyrics function (a string).
 * - `GenerateLyricsOutput`: The output type for the generateLyrics function (a string).
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateLyricsInputSchema = z.string().describe('A text prompt describing the desired song lyrics.');
export type GenerateLyricsInput = z.infer<typeof GenerateLyricsInputSchema>;

const GenerateLyricsOutputSchema = z.string().describe('The generated song lyrics.');
export type GenerateLyricsOutput = z.infer<typeof GenerateLyricsOutputSchema>;

/**
 * Generates song lyrics based on a text prompt.
 * @param input The text prompt describing the desired song lyrics.
 * @returns The generated song lyrics.
 */
export async function generateLyrics(input: GenerateLyricsInput): Promise<GenerateLyricsOutput> {
  return generateLyricsFlow(input);
}

const generateLyricsPrompt = ai.definePrompt({
  name: 'generateLyricsPrompt',
  input: {schema: GenerateLyricsInputSchema},
  output: {schema: GenerateLyricsOutputSchema},
  prompt: `You are a professional songwriter. Please write song lyrics based on the following description: {{{$input}}}`,
});

const generateLyricsFlow = ai.defineFlow(
  {
    name: 'generateLyricsFlow',
    inputSchema: GenerateLyricsInputSchema,
    outputSchema: GenerateLyricsOutputSchema,
  },
  async input => {
    const {output} = await generateLyricsPrompt(input);
    return output!;
  }
);
