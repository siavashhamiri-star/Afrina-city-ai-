'use server';

/**
 * @fileOverview This file defines a Genkit flow for generating various types of gaming content.
 *
 * It exports:
 * - `generateGamingContent`: An async function that takes a game name and content type and returns the generated text.
 * - `GenerateGamingContentInput`: The input type for the function.
 * - `GenerateGamingContentOutput`: The output type for the function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

export const GamingContentTypeSchema = z.enum([
    "review",
    "funny_moments_script",
    "lore_summary",
    "top_10_list",
    "beginner_guide",
    "custom"
]);
export type GamingContentType = z.infer<typeof GamingContentTypeSchema>;

const GenerateGamingContentInputSchema = z.object({
  gameName: z.string().describe('The name of the video game.'),
  contentType: GamingContentTypeSchema.describe('The type of content to generate.'),
  customPrompt: z.string().optional().describe('A custom prompt for more specific requests, like a "Top 10 list of weapons in [Game Name]" or a specific video idea.')
});
export type GenerateGamingContentInput = z.infer<typeof GenerateGamingContentInputSchema>;

const GenerateGamingContentOutputSchema = z.object({
    content: z.string().describe('The generated gaming content text.')
});
export type GenerateGamingContentOutput = z.infer<typeof GenerateGamingContentOutputSchema>;

/**
 * Generates gaming-related content based on the provided game and content type.
 * @param input An object containing the game name and content type.
 * @returns An object containing the generated content.
 */
export async function generateGamingContent(input: GenerateGamingContentInput): Promise<GenerateGamingContentOutput> {
  return generateGamingContentFlow(input);
}

const promptTemplates = {
    review: `You are a professional video game critic. Write a comprehensive review for the game "{{{gameName}}}". Cover gameplay, story, graphics, and sound. Be honest and provide a final score out of 10.`,
    funny_moments_script: `You are a YouTube content creator known for "Funny Moments" videos. Write a script for a video about "{{{gameName}}}". Include timestamps for potential funny events (e.g., glitches, player fails, hilarious NPC interactions) and add some comedic commentary.`,
    lore_summary: `You are a video game historian. Provide a concise but engaging summary of the main story and lore for "{{{gameName}}}". Focus on the key characters, factions, and events that a new player should know.`,
    top_10_list: `You are a listicle writer for a gaming website. Create a "Top 10" list related to "{{{gameName}}}". The specific topic is: "{{{customPrompt}}}". For each item, provide a short, punchy description.`,
    beginner_guide: `You are a helpful gaming mentor. Write a beginner's guide for "{{{gameName}}}". Include essential tips and tricks for new players, explaining core mechanics and what to focus on in the first few hours of playing.`,
    custom: `You are a helpful AI assistant for gamers. Fulfill the following request for the game "{{{gameName}}}": {{{customPrompt}}}`
};


const generateGamingContentFlow = ai.defineFlow(
  {
    name: 'generateGamingContentFlow',
    inputSchema: GenerateGamingContentInputSchema,
    outputSchema: GenerateGamingContentOutputSchema,
  },
  async input => {
    if ((input.contentType === 'top_10_list' || input.contentType === 'custom') && !input.customPrompt) {
        throw new Error('A custom prompt is required for this content type.');
    }

    const promptText = promptTemplates[input.contentType];
    
    const prompt = ai.definePrompt({
        name: `gamingContentPrompt_${input.contentType}`,
        prompt: promptText,
        input: { schema: GenerateGamingContentInputSchema },
    });

    const { text } = await prompt(input);
    return { content: text };
  }
);
