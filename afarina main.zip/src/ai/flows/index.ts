/**
 * @fileOverview Centralized AI flows for the Afarina platform.
 * This file imports and re-exports core AI functionalities to be used across the application,
 * while also wrapping them with credit deduction logic.
 */

'use server';

import { deductCredits } from '@/services/credit-service';

import { 
    generateLyrics as originalGenerateLyrics, 
    GenerateLyricsInput, 
    GenerateLyricsOutput 
} from './generate-lyrics-from-text';
import { 
    generateMusicFromText as originalGenerateMusic, 
    GenerateMusicFromTextInput, 
    GenerateMusicFromTextOutput 
} from './generate-music-from-text';
import { 
    generateNarrationFromText as originalGenerateNarration, 
    GenerateNarrationFromTextInput, 
    GenerateNarrationFromTextOutput 
} from './generate-narration-from-text';
import { 
    generateImageFromText as originalGenerateImage, 
    GenerateImageFromTextInput, 
    GenerateImageFromTextOutput 
} from './generate-image-from-text';
import { 
    generateAnimatedMusicVideo as originalGenerateVideo, 
    GenerateAnimatedMusicVideoInput, 
    GenerateAnimatedMusicVideoOutput 
} from './generate-animated-music-video';
import {
    removeVocalFromMusic as originalRemoveVocal,
    RemoveVocalFromMusicInput,
    RemoveVocalFromMusicOutput
} from './remove-vocal-from-music';
import {
    transformSimpleTextToNarrative as originalTransformText,
    TransformSimpleTextToNarrativeInput,
    TransformSimpleTextToNarrativeOutput
} from './transform-simple-text-to-narrative';

// Export types directly
export * from './generate-lyrics-from-text';
export * from './generate-music-from-text';
export * from './generate-narration-from-text';
export * from './generate-image-from-text';
export * from './generate-animated-music-video';
export * from './remove-vocal-from-music';
export * from './transform-simple-text-to-narrative';
export * from './chat-with-hamraz';


// Define credit costs
const CREDIT_COSTS = {
    lyrics: 1,
    narration: 2,
    image: 3,
    music: 5,
    vocalRemoval: 10,
    video: 20,
    narrative: 1,
};

// Wrapped flows with credit deduction
export async function generateLyrics(input: GenerateLyricsInput): Promise<GenerateLyricsOutput> {
    await deductCredits(CREDIT_COSTS.lyrics);
    return originalGenerateLyrics(input);
}

export async function generateMusicFromText(input: GenerateMusicFromTextInput): Promise<GenerateMusicFromTextOutput> {
    await deductCredits(CREDIT_COSTS.music);
    return originalGenerateMusic(input);
}

export async function generateNarrationFromText(input: GenerateNarrationFromTextInput): Promise<GenerateNarrationFromTextOutput> {
    await deductCredits(CREDIT_COSTS.narration);
    return originalGenerateNarration(input);
}

export async function generateImageFromText(input: GenerateImageFromTextInput): Promise<GenerateImageFromTextOutput> {
    await deductCredits(CREDIT_COSTS.image);
    return originalGenerateImage(input);
}

export async function generateAnimatedMusicVideo(input: GenerateAnimatedMusicVideoInput): Promise<GenerateAnimatedMusicVideoOutput> {
    await deductCredits(CREDIT_COSTS.video);
    return originalGenerateVideo(input);
}

export async function removeVocalFromMusic(input: RemoveVocalFromMusicInput): Promise<RemoveVocalFromMusicOutput> {
    await deductCredits(CREDIT_COSTS.vocalRemoval);
    return originalRemoveVocal(input);
}

export async function transformSimpleTextToNarrative(input: TransformSimpleTextToNarrativeInput): Promise<TransformSimpleTextToNarrativeOutput> {
    await deductCredits(CREDIT_COSTS.narrative);
    return originalTransformText(input);
}
