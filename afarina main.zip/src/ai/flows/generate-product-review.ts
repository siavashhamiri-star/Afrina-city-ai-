'use server';

/**
 * @fileOverview This file defines a Genkit flow that generates a product review script.
 *
 * It exports:
 * - `generateProductReview`: An async function that takes a product name and returns a review script.
 * - `GenerateProductReviewInput`: The input type for the function.
 * - `GenerateProductReviewOutput`: The output type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateProductReviewInputSchema = z.object({
  productName: z.string().describe('The name of the product to review.'),
  productCategory: z.string().describe('The category of the product (e.g., smartphone, laptop).'),
});
export type GenerateProductReviewInput = z.infer<typeof GenerateProductReviewInputSchema>;

const GenerateProductReviewOutputSchema = z.object({
    reviewScript: z.string().describe('The generated review script, including sections for unboxing, features, pros, cons, and a conclusion.')
});
export type GenerateProductReviewOutput = z.infer<typeof GenerateProductReviewOutputSchema>;

/**
 * Generates a product review script.
 * @param input An object containing the product name and category.
 * @returns An object containing the generated review script.
 */
export async function generateProductReview(input: GenerateProductReviewInput): Promise<GenerateProductReviewOutput> {
  return generateProductReviewFlow(input);
}

const generateProductReviewPrompt = ai.definePrompt({
  name: 'generateProductReviewPrompt',
  input: {schema: GenerateProductReviewInputSchema},
  output: {schema: GenerateProductReviewOutputSchema},
  prompt: `You are an expert tech reviewer. Your task is to create a comprehensive, fair, and engaging review script for a product. The script should be suitable for a YouTube video.

Product Name: {{{productName}}}
Product Category: {{{productCategory}}}

Please generate a script that includes the following sections:
1.  **Introduction:** Hook the audience, introduce the product, and state what the review will cover.
2.  **Unboxing:** Describe the packaging and the experience of opening it for the first time. What's in the box?
3.  **Design and Build Quality:** Talk about the product's aesthetics, materials, and how it feels to hold and use.
4.  **Key Features & Performance:** Detail the main features and how well they work in real-world usage.
5.  **Pros:** List the main advantages and strengths of the product.
6.  **Cons:** Provide a fair and balanced look at the disadvantages or weaknesses.
7.  **Conclusion & Verdict:** Summarize the review and give a final recommendation. Who is this product for? Is it worth the price?

The tone should be enthusiastic but honest and trustworthy. Format the output as a single block of text.`,
});

const generateProductReviewFlow = ai.defineFlow(
  {
    name: 'generateProductReviewFlow',
    inputSchema: GenerateProductReviewInputSchema,
    outputSchema: GenerateProductReviewOutputSchema,
  },
  async input => {
    const {output} = await generateProductReviewPrompt(input);
    return output!;
  }
);
