'use server';

/**
 * @fileOverview Generates a short promotional video for a live stream event.
 *
 * - generateLiveStreamVideo - A function to create the promo video.
 * - GenerateLiveStreamVideoInput - The input type for the function.
 * - GenerateLiveStreamVideoOutput - The output type for the function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GenerateLiveStreamVideoInputSchema = z.object({
  title: z.string().describe('The title of the live stream.'),
  description: z.string().describe('A brief description of what the live stream is about.'),
  streamUrl: z.string().url().describe('The URL of the live stream.'),
});
export type GenerateLiveStreamVideoInput = z.infer<typeof GenerateLiveStreamVideoInputSchema>;

const GenerateLiveStreamVideoOutputSchema = z.object({
  videoDataUri: z.string().describe('The generated promotional video as a data URI (MP4 format).'),
});
export type GenerateLiveStreamVideoOutput = z.infer<typeof GenerateLiveStreamVideoOutputSchema>;

export async function generateLiveStreamVideo(
  input: GenerateLiveStreamVideoInput
): Promise<GenerateLiveStreamVideoOutput> {
  return generateLiveStreamVideoFlow(input);
}

const generateLiveStreamVideoFlow = ai.defineFlow(
  {
    name: 'generateLiveStreamVideoFlow',
    inputSchema: GenerateLiveStreamVideoInputSchema,
    outputSchema: GenerateLiveStreamVideoOutputSchema,
  },
  async (input) => {
    
    const prompt = `A short, exciting promo video for a live stream. The stream is titled "${input.title}". 
    The theme is: "${input.description}". 
    The video should be dynamic, with energetic music and text overlays announcing the title and "Streaming Live!". 
    It should build anticipation.`;

    let { operation } = await ai.generate({
      model: 'veo-2.0-generate-001',
      prompt: prompt,
      config: {
        durationSeconds: 8,
        aspectRatio: '16:9',
      },
    });

    if (!operation) {
      throw new Error('Expected the model to return an operation');
    }

    // Wait until the operation completes.
    while (!operation.done) {
      operation = await ai.checkOperation(operation);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }

    if (operation.error) {
      throw new Error('Failed to generate video: ' + operation.error.message);
    }

    const video = operation.output?.message?.content.find(p => !!p.media);
    if (!video || !video.media?.url) {
      throw new Error('Failed to find the generated video in the operation result.');
    }

    return { videoDataUri: video.media.url };
  }
);
