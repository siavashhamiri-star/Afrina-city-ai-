'use server';

/**
 * @fileOverview Generates a cinematic promotional video from a text description.
 *
 * - generatePromoVideo - A function to create the promo video.
 * - GeneratePromoVideoInput - The input type for the function.
 * - GeneratePromoVideoOutput - The output type for the function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GeneratePromoVideoInputSchema = z.object({
  prompt: z.string().describe('The detailed prompt for the video, describing scenes and mood.'),
  musicDataUri: z.string().optional().describe('Optional music track as a data URI.'),
});
export type GeneratePromoVideoInput = z.infer<typeof GeneratePromoVideoInputSchema>;

const GeneratePromoVideoOutputSchema = z.object({
  videoDataUri: z.string().describe('The generated promotional video as a data URI (MP4 format).'),
});
export type GeneratePromoVideoOutput = z.infer<typeof GeneratePromoVideoOutputSchema>;

export async function generatePromoVideo(
  input: GeneratePromoVideoInput
): Promise<GeneratePromoVideoOutput> {
  return generatePromoVideoFlow(input);
}

const generatePromoVideoFlow = ai.defineFlow(
  {
    name: 'generatePromoVideoFlow',
    inputSchema: GeneratePromoVideoInputSchema,
    outputSchema: GeneratePromoVideoOutputSchema,
  },
  async (input) => {
    
    const prompts: any[] = [{ text: input.prompt }];
    if (input.musicDataUri) {
      prompts.push({ media: { url: input.musicDataUri } });
    }

    let { operation } = await ai.generate({
      model: 'veo-2.0-generate-001',
      prompt: prompts,
      config: {
        durationSeconds: 15,
        aspectRatio: '16:9',
      },
    });

    if (!operation) {
      throw new Error('Expected the model to return an operation');
    }

    // Wait until the operation completes.
    while (!operation.done) {
      operation = await ai.checkOperation(operation);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }

    if (operation.error) {
      throw new Error('Failed to generate video: ' + operation.error.message);
    }

    const video = operation.output?.message?.content.find(p => !!p.media);
    if (!video || !video.media?.url) {
      throw new Error('Failed to find the generated video in the operation result.');
    }

    return { videoDataUri: video.media.url };
  }
);
