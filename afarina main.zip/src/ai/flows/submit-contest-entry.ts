'use server';

/**
 * @fileOverview Handles submissions for internal platform contests.
 *
 * - submitContestEntry - A function that processes a user's contest submission.
 * - SubmitContestEntryInput - The input type for the function.
 * - SubmitContestEntryOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

export const ContestTypeSchema = z.enum(['dubsmash', 'animation', 'dubbing', 'remix']);
export type ContestType = z.infer<typeof ContestTypeSchema>;

const SubmitContestEntryInputSchema = z.object({
  contestType: ContestTypeSchema.describe('The type of contest the entry is for.'),
  entryDataUri: z
    .string()
    .describe(
      'The contest entry file (video or audio), as a data URI that must include a MIME type and use Base64 encoding.'
    ),
  userNotes: z.string().optional().describe('Optional notes from the user about their submission.'),
});
export type SubmitContestEntryInput = z.infer<typeof SubmitContestEntryInputSchema>;

const SubmitContestEntryOutputSchema = z.object({
  submissionId: z.string().describe('The unique ID for the submitted entry.'),
  confirmationMessage: z.string().describe('A confirmation message for the user.'),
});
export type SubmitContestEntryOutput = z.infer<typeof SubmitContestEntryOutputSchema>;

/**
 * Processes a user's submission for a contest.
 * @param input An object containing the contest type and the entry data.
 * @returns An object containing a submission ID and a confirmation message.
 */
export async function submitContestEntry(
  input: SubmitContestEntryInput
): Promise<SubmitContestEntryOutput> {
  return submitContestEntryFlow(input);
}

const submitContestEntryFlow = ai.defineFlow(
  {
    name: 'submitContestEntryFlow',
    inputSchema: SubmitContestEntryInputSchema,
    outputSchema: SubmitContestEntryOutputSchema,
  },
  async input => {
    // In a real application, you would save this entry to a database (e.g., Firestore)
    // and associate it with the user's ID.
    console.log(`Received entry for ${input.contestType} contest.`);

    // For now, we'll just generate a random ID and return a success message.
    const submissionId = `entry_${Math.random().toString(36).substring(2, 11)}`;

    return {
      submissionId,
      confirmationMessage: `Your entry for the ${input.contestType} contest has been successfully submitted with ID: ${submissionId}. Good luck!`,
    };
  }
);
