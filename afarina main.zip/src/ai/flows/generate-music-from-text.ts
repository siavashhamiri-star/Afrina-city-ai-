'use server';

/**
 * @fileOverview Generates music from a text description using AI.
 *
 * - generateMusicFromText - A function that generates a music track based on a text description.
 * - GenerateMusicFromTextInput - The input type for the generateMusicFromText function.
 * - GenerateMusicFromTextOutput - The return type for the generateMusicFromText function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateMusicFromTextInputSchema = z.object({
  description: z
    .string()
    .describe(
      'A text description of the desired music track, including style, theme, and mood.'
    ),
});
export type GenerateMusicFromTextInput = z.infer<
  typeof GenerateMusicFromTextInputSchema
>;

const GenerateMusicFromTextOutputSchema = z.object({
  musicDataUri: z
    .string()
    .describe(
      'The generated music track as a data URI (e.g., audio/mpeg;base64,...).'
    ),
});
export type GenerateMusicFromTextOutput = z.infer<
  typeof GenerateMusicFromTextOutputSchema
>;

export async function generateMusicFromText(
  input: GenerateMusicFromTextInput
): Promise<GenerateMusicFromTextOutput> {
  return generateMusicFromTextFlow(input);
}

const generateMusicPrompt = ai.definePrompt({
  name: 'generateMusicPrompt',
  input: {schema: GenerateMusicFromTextInputSchema},
  output: {schema: GenerateMusicFromTextOutputSchema},
  prompt: `You are an AI music composer. Please compose a unique music track based on the following description: {{{description}}}. The output should be a base64 encoded data URI of the music in MP3 format.  Ensure that the data URI is properly formatted and includes the audio/mpeg MIME type, e.g., 'data:audio/mpeg;base64,<base64_encoded_music>'. Ensure that the music can be played, is complete and of high quality.`,
});

const generateMusicFromTextFlow = ai.defineFlow(
  {
    name: 'generateMusicFromTextFlow',
    inputSchema: GenerateMusicFromTextInputSchema,
    outputSchema: GenerateMusicFromTextOutputSchema,
  },
  async input => {
    // Invoke the music generation prompt to create the track
    const {output} = await generateMusicPrompt(input);

    return output!;
  }
);
