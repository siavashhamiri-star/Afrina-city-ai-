'use server';

/**
 * @fileOverview A Genkit flow that translates text to a specified target language.
 *
 * It exports:
 * - `translateText`: An async function that takes a text and a target language and returns the translated text.
 * - `TranslateTextInput`: The input type for the function.
 * - `TranslateTextOutput`: The output type for the function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const TranslateTextInputSchema = z.object({
  text: z.string().describe('The text to be translated.'),
  targetLanguage: z.string().describe('The target language for translation (e.g., "Spanish", "French", "fa").'),
});
export type TranslateTextInput = z.infer<typeof TranslateTextInputSchema>;

const TranslateTextOutputSchema = z.object({
    translatedText: z.string().describe('The resulting translated text.'),
});
export type TranslateTextOutput = z.infer<typeof TranslateTextOutputSchema>;

/**
 * Translates text to a specified target language.
 * @param input An object containing the text to translate and the target language.
 * @returns An object containing the translated text.
 */
export async function translateText(input: TranslateTextInput): Promise<TranslateTextOutput> {
  return translateTextFlow(input);
}

const translateTextPrompt = ai.definePrompt({
  name: 'translateTextPrompt',
  input: { schema: TranslateTextInputSchema },
  output: { schema: TranslateTextOutputSchema },
  prompt: `Translate the following text to {{{targetLanguage}}}. Only return the translated text, with no additional commentary or explanations.\n\nText to translate:\n\`\`\`\n{{{text}}}\n\`\`\``,
});

const translateTextFlow = ai.defineFlow(
  {
    name: 'translateTextFlow',
    inputSchema: TranslateTextInputSchema,
    outputSchema: TranslateTextOutputSchema,
  },
  async input => {
    const { output } = await translateTextPrompt(input);
    return output!;
  }
);
