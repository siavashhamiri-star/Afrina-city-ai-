import { config } from 'dotenv';
config();

// Import only the flows that need to be active in development
import '@/ai/flows/generate-lyrics-from-text';
import '@/ai/flows/generate-music-from-text';
import '@/ai/flows/generate-narration-from-text';
import '@/ai/flows/generate-image-from-text';
import '@/ai/flows/generate-animated-music-video';
import '@/ai/flows/remove-vocal-from-music';
import '@/ai/flows/transform-simple-text-to-narrative';
import '@/ai/flows/chat-with-hamraz';
