'use client';

import { getAuth, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useFirestore } from '@/firebase';
import { doc, setDoc, serverTimestamp, getDoc } from 'firebase/firestore';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Globe } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const auth = getAuth();
  const firestore = useFirestore();

  const handleGoogleSignIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      if (user && firestore) {
        const userDocRef = doc(firestore, 'users', user.uid);
        const userDoc = await getDoc(userDocRef);

        if (!userDoc.exists()) {
          await setDoc(userDocRef, {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName,
            photoURL: user.photoURL,
            createdAt: serverTimestamp(),
            credits: 100, // Monthly initial credits
            lastCreditReset: serverTimestamp(),
          });
        }
      }

      router.push('/dashboard');
    } catch (error) {
      console.error('Error signing in with Google: ', error);
    }
  };
  
  const handleGuestAccess = () => {
      router.push('/dashboard/hamraz?guest=true');
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-background p-4" dir="rtl">
      <Card className="w-full max-w-md border-primary/20 shadow-2xl">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto bg-primary/10 p-4 rounded-full w-fit">
            <Globe className="h-10 w-10 text-primary" />
          </div>
          <CardTitle className="text-3xl font-headline font-bold">ورود به اکوسیستم آفرینا</CardTitle>
          <CardDescription className="text-lg">
            به عنوان یک «آفرینشگر و مالک» وارد شوید و قدرت آفرینش را به دست بگیرید.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Button onClick={handleGoogleSignIn} className="w-full h-12 text-lg" size="lg">
            ورود با حساب گوگل
          </Button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground font-bold">
                یا به عنوان مهمان تجربه کنید
              </span>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="invitation-code" className="font-bold">کد دعوت دارید؟</Label>
            <Input id="invitation-code" placeholder="کد را اینجا وارد کنید..." className="h-12 text-left" />
            <p className="text-xs text-muted-foreground">
              کد دعوت به شما اجازه می‌دهد ۲۴ ساعت تمام قابلیت‌ها را بدون محدودیت تست کنید.
            </p>
          </div>

        </CardContent>
        <CardFooter className="flex flex-col gap-4">
            <Button variant="secondary" className="w-full h-12" onClick={handleGuestAccess}>ورود مهمان به «همراز»</Button>
            <p className="text-[10px] text-center text-muted-foreground">
              با ورود به آفرینا، شما منشور اخلاقی و پیمان‌نامه مالکیت اشتراکی ما را می‌پذیرید.
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}
