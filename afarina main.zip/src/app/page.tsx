import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/site-header";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { ArrowRight, Globe, ShieldCheck, Zap, Users, Award, Gift } from "lucide-react";

export default function Home() {
  const heroImage = PlaceHolderImages.find(p => p.id === "landing_hero");
  
  return (
    <div className="flex flex-col min-h-screen" dir="rtl">
      <SiteHeader />
      <main className="flex-1">
        <section className="relative w-full py-20 md:py-32 lg:py-40 overflow-hidden">
          <div className="container mx-auto px-4 md:px-6 text-center">
            <div className="max-w-4xl mx-auto">
              <div className="inline-block rounded-lg bg-primary/10 text-primary px-3 py-1 text-sm font-bold mb-6 flex items-center justify-center gap-2 w-fit mx-auto">
                <Globe className="h-4 w-4" />
                اکوسیستم دموکراتیک جهانی
              </div>
              <h1 className="text-4xl md:text-7xl font-headline font-bold tracking-tight text-foreground mb-6">
                آفرینا: آغاز خلاقیت دموکراتیک
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-10 leading-relaxed max-w-3xl mx-auto">
                ما مرزهای میان مصرف‌کننده و مالک را فروریخته‌ایم تا اکوسیستمی جهانی بنا کنیم که در آن، تکنولوژی نه در خدمتِ انحصارات، بلکه ابزاری در دستانِ هر انسان برای توانمندسازیِ مطلق است.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button asChild size="lg" className="text-lg px-8">
                  <Link href="/dashboard">
                    شروع رایگان آفرینش <ArrowRight className="mr-2 h-5 w-5 rotate-180" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="text-lg px-8">
                  <Link href="/dashboard/hamraz?guest=true">
                    گفتگو با همراز (مهمان)
                  </Link>
                </Button>
              </div>
            </div>
          </div>
          {heroImage && (
             <div className="absolute inset-0 -z-10">
                <Image
                    src={heroImage.imageUrl}
                    alt={heroImage.description}
                    fill
                    className="object-cover"
                    data-ai-hint={heroImage.imageHint}
                    priority
                />
                <div className="absolute inset-0 bg-background/85 backdrop-blur-sm"></div>
            </div>
          )}
        </section>

        <section id="manifesto" className="w-full py-16 md:py-24 bg-primary/5 border-y">
            <div className="container mx-auto px-4 md:px-6 text-center">
                <h2 className="text-3xl md:text-5xl font-headline font-bold mb-8">بیانیه‌ی آفرینا (مانیفست)</h2>
                <p className="text-lg md:text-2xl leading-loose max-w-4xl mx-auto text-foreground/90 italic font-medium">
                    «در آفرینا، شما فقط خلق نمی‌کنید، بلکه در مالکیت و موفقیتِ پلتفرمی که با هنر شما جان می‌گیرد، شریک هستید. این انقلابی علیه انحصار است؛ جایی که هوش مصنوعی، عدالت و شفافیت مالی ۹۰/۱۰ با هم تلاقی می‌کنند تا هر انسان، یک آفرینشگرِ آزاد باشد.»
                </p>
            </div>
        </section>

        <section className="w-full py-12 md:py-24 bg-card">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid gap-8 md:grid-cols-3">
              <div className="flex flex-col items-center text-center p-6 space-y-4">
                <div className="p-4 bg-primary/10 rounded-full"><ShieldCheck className="h-8 w-8 text-primary" /></div>
                <h3 className="text-xl font-bold font-headline">شفافیت مالی ۹۰/۱۰</h3>
                <p className="text-muted-foreground">۹۰٪ از ارزش خلق شده متعلق به شماست. ما فقط ۱۰٪ را برای توسعه زیرساخت برمی‌داریم.</p>
              </div>
              <div className="flex flex-col items-center text-center p-6 space-y-4">
                <div className="p-4 bg-primary/10 rounded-full"><Zap className="h-8 w-8 text-primary" /></div>
                <h3 className="text-xl font-bold font-headline">توانمندسازی مطلق</h3>
                <p className="text-muted-foreground">دسترسی دموکراتیک به پیشرفته‌ترین ابزارهای AI برای هر انسان در هر کجای جهان.</p>
              </div>
              <div className="flex flex-col items-center text-center p-6 space-y-4">
                <div className="p-4 bg-primary/10 rounded-full"><Users className="h-8 w-8 text-primary" /></div>
                <h3 className="text-xl font-bold font-headline">مالکیت اشتراکی</h3>
                <p className="text-muted-foreground">در آفرینا، کاربران همان مالکان هستند. موفقیت پلتفرم مستقیماً به جیب شما بازمی‌گردد.</p>
              </div>
            </div>
          </div>
        </section>

        <section id="community" className="w-full py-12 md:py-24 lg:py-32 bg-primary/5">
          <div className="container mx-auto px-4 md:px-6 text-center">
             <div className="flex flex-col items-center justify-center space-y-4">
                <h2 className="text-3xl font-headline font-bold tracking-tighter sm:text-5xl">تغییر جهان، یک جرقه در یک زمان</h2>
                <p className="max-w-3xl mx-auto text-xl text-primary font-bold md:text-3xl/relaxed mb-4 mt-6">
                  "دلتان برای دوستانتان تنگ می‌شود و قلبتان برای دیدنشان خواهد تپید."
                </p>
                <p className="max-w-4xl mx-auto text-muted-foreground md:text-xl/relaxed leading-loose">
                  آفرینا یک پلتفرم نیست، یک میثاق است. ما با روح تعامل، قلب‌های خیرخواه و اتحاد، در دنیای اپ‌ها خواهیم درخشید. موفقیتِ هر عضو، لبخندی بر لبانِ تمام جامعه است.
                </p>
                <div className="flex gap-4 mt-10">
                   <Button asChild size="lg" className="px-12 text-lg">
                    <Link href="/login">
                      ثبت‌نام و دریافت سهام آفرینش <Users className="mr-2 h-5 w-5" />
                    </Link>
                  </Button>
                </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-card border-t py-12">
        <div className="container mx-auto px-4 md:px-6 flex flex-col md:flex-row items-center justify-between">
          <div className="flex flex-col items-center md:items-start gap-2">
            <p className="text-lg font-bold font-headline">Afarina</p>
            <p className="text-sm text-muted-foreground">© {new Date().getFullYear()} تمام حقوق برای جامعه‌ی آفرینشگرانِ آزاد محفوظ است.</p>
          </div>
          <nav className="flex gap-6 mt-8 md:mt-0">
            <Link href="#" className="text-sm hover:text-primary transition-colors">قوانین دموکراتیک</Link>
            <Link href="#" className="text-sm hover:text-primary transition-colors">شفافیت مالی</Link>
            <Link href="#" className="text-sm hover:text-primary transition-colors">تماس با شورا</Link>
          </nav>
        </div>
      </footer>
    </div>
  );
}
