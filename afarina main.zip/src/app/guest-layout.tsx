import { GuestHeader } from "@/components/guest-header";

interface GuestLayoutProps {
    children: React.ReactNode;
}

export default function GuestLayout({ children }: GuestLayoutProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <GuestHeader />
      <main className="flex w-full flex-col overflow-hidden">
        {children}
      </main>
    </div>
  );
}
