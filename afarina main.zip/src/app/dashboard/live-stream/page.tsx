'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { generateLiveStreamVideo } from '@/ai/flows/generate-live-stream-video';
import { Clapperboard, Video } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const formSchema = z.object({
  streamUrl: z.string().url('Please enter a valid URL for your live stream.'),
  title: z.string().min(5, 'Please provide a catchy title for your stream.'),
  description: z.string().min(10, 'Describe what your live stream is about.'),
});

export default function LiveStreamPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [promoVideo, setPromoVideo] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      streamUrl: '',
      title: '',
      description: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setPromoVideo(null);
    try {
      const response = await generateLiveStreamVideo(values);
      setPromoVideo(response.videoDataUri);
      toast({
        title: 'Promo Video Generated!',
        description: 'Your promotional video is ready. Use it to advertise your stream!',
      });
    } catch (error) {
      console.error(error);
      toast({
        title: 'An error occurred.',
        description: 'Failed to generate the promo video. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="container py-8">
      <PageHeader
        title="Live Stream Studio"
        description="Promote your live events and prepare for the future of AI-driven streaming."
      />

       <Alert className="mb-8 border-primary/50 bg-primary/10">
          <Clapperboard className="h-4 w-4" />
          <AlertTitle className="font-bold">ایده انقلابی: شوالیه رسانه (The Media Knight)</AlertTitle>
          <AlertDescription>
            به زودی، شما برای تبدیل شدن به یک استریمر به هیچ تجهیزاتی نیاز نخواهید داشت. هوش مصنوعی انقلابی ما، «شوالیه رسانه»، آواتار مجازی شما خواهد بود. شما سناریو را می‌نویسید و شوالیه هوشمند شما آن را اجرا می‌کند، با مخاطبان تعامل دارد و استریم را برای شما مدیریت می‌کند. آنچه اینجا می‌بینید، اولین قدم در این مسیر شگفت‌انگیز است.
          </AlertDescription>
        </Alert>

      <div className="grid gap-8 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Schedule Your Live Stream</CardTitle>
            <CardDescription>
              For now, link your YouTube, Twitch, or other live stream. Our AI will generate a short promotional video for it.
            </CardDescription>
          </CardHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="streamUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Live Stream URL</FormLabel>
                      <FormControl>
                        <Input placeholder="https://youtube.com/live/..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Stream Title</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., My First Live Q&A!" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Stream Description</FormLabel>
                      <FormControl>
                        <Textarea placeholder="e.g., Join me as I play the new fantasy RPG and answer your questions live!" {...field} />
                      </FormControl>
                       <FormDescription>This helps the AI create a relevant promo video.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
              <CardFooter>
                <Button type="submit" disabled={isLoading} size="lg">
                    {isLoading ? <LoadingSpinner className="mr-2 h-4 w-4" /> : <Video className="mr-2 h-4 w-4" />}
                    {isLoading ? 'Generating Promo...' : 'Generate Promo Video'}
                </Button>
              </CardFooter>
            </form>
          </Form>
        </Card>

        <Card>
            <CardHeader>
                <CardTitle>Your Promotional Video</CardTitle>
                 <CardDescription>
                    Share this video on your social media to get more viewers for your live stream!
                </CardDescription>
            </CardHeader>
            <CardContent>
                {promoVideo ? (
                     <video controls src={promoVideo} className="w-full rounded-lg" >
                        Your browser does not support the video tag.
                    </video>
                ) : (
                    <div className="flex flex-col items-center justify-center w-full h-64 bg-muted rounded-lg">
                        <Video className="h-16 w-16 text-muted-foreground" />
                        <p className="text-muted-foreground mt-2">Your generated video will appear here.</p>
                    </div>
                )}
            </CardContent>
            {promoVideo && (
                <CardFooter>
                    <Button asChild>
                        <a href={promoVideo} download="live_stream_promo.mp4">Download Video</a>
                    </Button>
                </CardFooter>
            )}
        </Card>
      </div>
    </div>
  );
}
