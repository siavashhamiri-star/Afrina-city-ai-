
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useUser } from '@/firebase/auth/use-user';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ShieldCheck, Star, Shield, PlusCircle, Handshake, Users, Vote, Brush, MoreVertical, UserPlus, MessageSquare, UserMinus, User, Flag, ShieldAlert, Copy, Quote, Save } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '@/components/ui/textarea';


type Role = 'Admin' | 'Captain' | 'Co-Captain' | 'Member';

interface Member {
  id: string;
  name: string;
  avatar: string;
  role: Role;
  score: number;
  joined: string;
  followers: number;
  following: number;
  statusMessage?: string;
}

// Mock data for community members
const mockMembers: Member[] = [
  { id: '1', name: 'Alireza', avatar: 'https://i.pravatar.cc/150?u=user1', role: 'Admin', score: 980, joined: '2023-01-15', followers: 1200, following: 50, statusMessage: 'Excited to see the creativity in this community! ✨' },
  { id: '2', name: 'Sara', avatar: 'https://i.pravatar.cc/150?u=user2', role: 'Captain', score: 850, joined: '2023-02-20', followers: 950, following: 80, statusMessage: 'Working on a new song, can\'t wait to share it!' },
  { id: '3', name: 'Mina', avatar: 'https://i.pravatar.cc/150?u=user3', role: 'Co-Captain', score: 720, joined: '2023-03-10', followers: 700, following: 120, statusMessage: 'Feeling inspired today.' },
  { id: '4', name: 'Kian', avatar: 'https://i.pravatar.cc/150?u=user4', role: 'Member', score: 540, joined: '2023-05-01', followers: 450, following: 200 },
  { id: '5', name: 'Nazanin', avatar: 'https://i.pravatar.cc/150?u=user5', role: 'Member', score: 410, joined: '2023-07-22', followers: 300, following: 150, statusMessage: 'Just joined, hello everyone!' },
  { id: '6', name: 'Amir', avatar: 'https://i.pravatar.cc/150?u=user6', role: 'Member', score: 320, joined: '2023-09-01', followers: 180, following: 300 },
];

function RoleBadge({ role }: { role: Role }) {
  const roleConfig = {
    Admin: { icon: <ShieldCheck className="h-3.5 w-3.5" />, color: 'bg-red-500 text-white' },
    Captain: { icon: <Star className="h-3.5 w-3.5" />, color: 'bg-amber-500 text-white' },
    'Co-Captain': { icon: <Shield className="h-3.5 w-3.5" />, color: 'bg-blue-500 text-white' },
    Member: { icon: null, color: 'bg-secondary text-secondary-foreground' },
  };
  
  const config = roleConfig[role as keyof typeof roleConfig] || roleConfig.Member;

  return (
    <Badge variant="secondary" className={`gap-1.5 ${config.color}`}>
      {config.icon}
      {role}
    </Badge>
  );
}

export default function CommunityHubPage() {
  const { user } = useUser();
  const { toast } = useToast();
  const [members, setMembers] = useState<Member[]>(mockMembers);
  const [myStatus, setMyStatus] = useState("Excited to see the creativity in this community! ✨");
  const totalScore = members.reduce((sum, member) => sum + member.score, 0);

  const userInitial = user?.displayName ? user.displayName.charAt(0).toUpperCase() : '?';

  // Mock data for family stats and referral code
  const familyFollowers = 5200;
  const familyAlliances = 3;
  const referralCode = `AFARINA-${user?.uid.slice(0, 6).toUpperCase() || 'USER123'}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralCode).then(() => {
        toast({
            title: "Copied to Clipboard!",
            description: "Your referral code has been copied.",
        });
    });
  }

  const handleStatusSave = () => {
      // In a real app, you would save this to your database (e.g., Firestore)
      toast({
          title: "Status Updated!",
          description: "Your new status message has been saved.",
      });
  }

  return (
    <div className="container py-8">
      <PageHeader
        title="Community & Family Hub"
        description="Manage your family, share your mood, and track member activity."
      />

        <div className="grid md:grid-cols-1 lg:grid-cols-2 gap-4 mb-8">
             <Alert className="lg:col-span-2 border-red-500/50 bg-red-500/10 text-red-700 dark:text-red-300">
                <ShieldAlert className="h-4 w-4 text-red-500" />
                <AlertTitle className="font-bold">خط قرمزهای جامعه آفرینا: احترام و امنیت</AlertTitle>
                <AlertDescription>
                    حفظ یک محیط امن و محترمانه، اولویت اصلی ماست. هیچکس نباید با رفتارهایش باعث ناراحتی و دلسردی دیگران شود. آفرینا هیچ گرایش سیاسی یا قومی را نمایندگی نمی‌کند و کانالی اجتماعی در خدمت فرهنگ و اصول انسانی است. هرگونه توهین، نژادپرستی، توهین به فرهنگ‌ها و ادیان، محتوای خشونت‌آمیز, بزرگسال یا وحشت‌آور، سوءاستفاده از کودکان، تجارت غیرقانونی، و همچنین تبلیغ جنگ، مسائل سیاسی یا انتخاباتی اکیداً ممنوع است و منجر به مسدود شدن دائمی حساب خواهد شد.
                </AlertDescription>
            </Alert>
             <Alert className="border-green-500/50 bg-green-500/10 text-green-700 dark:text-green-300">
                <Handshake className="h-4 w-4 text-green-500" />
                <AlertTitle className="font-bold">قانون دوستی: رشد دو برابر!</AlertTitle>
                <AlertDescription>
                    افرادی که دست دوستی به یکدیگر بدهند و با هم همکاری کنند، دو برابر امتیاز کسب کرده و سریع‌تر سطح خود را بالا می‌برند.
                </AlertDescription>
            </Alert>
            <Alert className="border-blue-500/50 bg-blue-500/10 text-blue-700 dark:text-blue-300">
                <Users className="h-4 w-4 text-blue-500" />
                <AlertTitle className="font-bold">اتحاد خانواده‌ها و روم‌ها</AlertTitle>
                <AlertDescription>
                   با خانواده‌های دیگر متحد شوید! اتحادها پاداش‌های ویژه‌ای دریافت کرده و رشد تمام اعضا را تسریع می‌کنند.
                </AlertDescription>
            </Alert>
        </div>

      <div className="grid lg:grid-cols-3 gap-8 mb-8">
        <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Quote className="h-6 w-6 text-primary" />
                My Status Message
              </CardTitle>
              <CardDescription>
                Share your current mood or a short thought with the community.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <Textarea 
                    value={myStatus}
                    onChange={(e) => setMyStatus(e.target.value)}
                    placeholder="What's on your mind?"
                    maxLength={100}
                />
                 <Button onClick={handleStatusSave} className="w-full">
                    <Save className="mr-2 h-4 w-4" />
                    Save Status
                </Button>
            </CardContent>
        </Card>

        <Card className="lg:col-span-2">
            <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <UserPlus className="h-6 w-6 text-primary" />
                Grow Your Family & Earn Points
            </CardTitle>
            <CardDescription>
                Invite your friends to join Afarina! For every friend that signs up using your code, you'll both receive bonus points.
            </CardDescription>
            </CardHeader>
            <CardContent>
            <div className="flex items-center space-x-2">
                <div className="grid flex-1 gap-2">
                <Label htmlFor="referral-code" className="sr-only">
                    Referral Code
                </Label>
                <Input id="referral-code" value={referralCode} readOnly />
                </div>
                <Button type="button" size="sm" className="px-3" onClick={copyToClipboard}>
                <span className="sr-only">Copy</span>
                <Copy className="h-4 w-4" />
                </Button>
            </div>
            </CardContent>
        </Card>
      </div>


      <Card>
        <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
                 <CardTitle className="flex items-center gap-4">
                    <Avatar className="h-12 w-12 border-2 border-primary">
                      {/* In a real app, this would be the family's uploaded logo */}
                       <AvatarFallback className="bg-primary/20 text-primary">AC</AvatarFallback>
                    </Avatar>
                    Afarina Creators Family
                 </CardTitle>
                 <CardDescription className="mt-2 flex flex-wrap gap-x-4 gap-y-1">
                    <span>Total Score: <span className="font-bold text-primary">{totalScore.toLocaleString()}</span></span>
                    <span>Followers: <span className="font-bold text-primary">{familyFollowers.toLocaleString()}</span></span>
                    <span>Alliances: <span className="font-bold text-primary">{familyAlliances}</span></span>
                 </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button asChild variant="outline">
                <Link href="/dashboard/ad-creator">
                  <Brush className="mr-2 h-4 w-4" />
                  Design Family Logo
                </Link>
              </Button>
              <Button>
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Recruit New Member
              </Button>
            </div>
        </CardHeader>
        <CardContent>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Member</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Followers</TableHead>
                        <TableHead>Following</TableHead>
                        <TableHead>Activity Score</TableHead>
                        <TableHead>Contribution</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {members.map((member) => (
                        <TableRow key={member.id}>
                            <TableCell>
                                <div className="flex items-center gap-3">
                                    <Avatar className="h-10 w-10">
                                        <AvatarImage src={member.avatar} alt={member.name} />
                                        <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <p className="font-medium">{member.name}</p>
                                        <p className="text-sm text-muted-foreground">Joined: {new Date(member.joined).toLocaleDateString()}</p>
                                        {member.statusMessage && (
                                            <div className="flex items-center gap-1.5 mt-1 text-xs text-muted-foreground italic">
                                                <Quote className="h-3 w-3" />
                                                <span>{member.statusMessage}</span>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </TableCell>
                            <TableCell>
                                <RoleBadge role={member.role} />
                            </TableCell>
                            <TableCell>{member.followers.toLocaleString()}</TableCell>
                            <TableCell>{member.following.toLocaleString()}</TableCell>
                            <TableCell className="font-mono text-lg">{member.score.toLocaleString()}</TableCell>
                            <TableCell>
                               <div className="flex items-center gap-2">
                                 <span className="text-sm text-muted-foreground">{((member.score / totalScore) * 100).toFixed(1)}%</span>
                                 <Progress value={(member.score / totalScore) * 100} className="w-24"/>
                               </div>
                            </TableCell>
                            <TableCell className="text-right">
                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" size="icon">
                                            <MoreVertical className="h-4 w-4" />
                                            <span className="sr-only">Actions for {member.name}</span>
                                        </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end">
                                        <DropdownMenuItem>
                                            <User className="mr-2 h-4 w-4" />
                                            View Profile
                                        </DropdownMenuItem>
                                        <DropdownMenuItem>
                                            <MessageSquare className="mr-2 h-4 w-4" />
                                            Send Message
                                        </DropdownMenuItem>
                                        <DropdownMenuItem>
                                            <UserPlus className="mr-2 h-4 w-4" />
                                            Follow User
                                        </DropdownMenuItem>
                                        <DropdownMenuSeparator />
                                        <DropdownMenuItem className="text-destructive">
                                            <UserMinus className="mr-2 h-4 w-4" />
                                            Ignore User
                                        </DropdownMenuItem>
                                        <DropdownMenuItem className="text-destructive">
                                            <Flag className="mr-2 h-4 w-4" />
                                            Report User
                                        </DropdownMenuItem>
                                    </DropdownMenuContent>
                                </DropdownMenu>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </CardContent>
      </Card>
    </div>
  );
}
