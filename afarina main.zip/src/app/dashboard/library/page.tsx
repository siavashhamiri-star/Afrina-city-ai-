'use client';

import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Music, Video, Image as ImageIcon, Upload, Download } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

// Mock data - in the future, this will come from Firestore
const mockAssets = [
  { id: '1', name: 'epic-trailer-music.mp3', type: 'audio', source: 'generated', createdAt: '2024-07-28' },
  { id: '2', name: 'my-new-song-vocals.wav', type: 'audio', source: 'uploaded', createdAt: '2024-07-27' },
  { id: '3', name: 'my-new-song-instrumental.mp3', type: 'audio', source: 'vocal-removed', createdAt: '2024-07-27' },
  { id: '4', name: 'promo-video.mp4', type: 'video', source: 'generated', createdAt: '2024-07-26' },
  { id: '5', name: 'logo-design.png', type: 'image', source: 'generated', createdAt: '2024-07-25' },
];

function AssetIcon({ type }: { type: string }) {
    switch (type) {
        case 'audio': return <Music className="h-6 w-6 text-primary" />;
        case 'video': return <Video className="h-6 w-6 text-primary" />;
        case 'image': return <ImageIcon className="h-6 w-6 text-primary" />;
        default: return <Music className="h-6 w-6 text-primary" />;
    }
}


export default function LibraryPage() {
  return (
    <div className="container py-8">
      <div className="flex justify-between items-center mb-8">
        <PageHeader
          title="My Library"
          description="Your personal archive of all creative assets."
        />
        <Button>
            <Upload className="mr-2 h-4 w-4" />
            Upload New Asset
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Assets</CardTitle>
          <CardDescription>
            Manage your uploaded files and AI-generated content.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockAssets.map(asset => (
              <div key={asset.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-secondary/50">
                <div className="flex items-center gap-4 flex-1 min-w-0">
                  <AssetIcon type={asset.type} />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold truncate">{asset.name}</p>
                    <p className="text-sm text-muted-foreground">
                      Created on {new Date(asset.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4 ml-4">
                    <Badge variant={asset.source === 'generated' ? 'default' : 'secondary'}>{asset.source}</Badge>
                    <Button variant="outline" size="icon">
                        <Download className="h-4 w-4" />
                        <span className="sr-only">Download {asset.name}</span>
                    </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
