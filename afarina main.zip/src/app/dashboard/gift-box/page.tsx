'use client';

import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Gift, Rose, Heart, Disc, Coffee, Gem, Star } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface GiftItem {
  name: string;
  count: number;
  icon: LucideIcon;
  rarity: 'common' | 'rare' | 'epic';
}

// Mock data for the user's gift inventory
const mockGifts: GiftItem[] = [
  { name: 'Rose', count: 25, icon: Rose, rarity: 'common' },
  { name: 'Heart', count: 58, icon: Heart, rarity: 'common' },
  { name: 'Coffee', count: 12, icon: Coffee, rarity: 'rare' },
  { name: 'Golden Vinyl', count: 5, icon: Disc, rarity: 'rare' },
  { name: 'Diamond Gem', count: 2, icon: Gem, rarity: 'epic' },
  { name: 'Shooting Star', count: 1, icon: Star, rarity: 'epic' },
];

const rarityColors = {
    common: 'bg-gray-500',
    rare: 'bg-blue-600',
    epic: 'bg-purple-600',
}

function GiftCard({ gift }: { gift: GiftItem }) {
    const Icon = gift.icon;
    return (
        <Card className="text-center flex flex-col items-center justify-center p-4 transition-transform hover:scale-105 hover:shadow-lg">
            <Icon className="h-12 w-12 text-primary mb-3" />
            <p className="font-bold text-lg">{gift.name}</p>
            <p className="text-3xl font-headline">{gift.count}</p>
            <Badge className={`mt-2 ${rarityColors[gift.rarity]}`}>{gift.rarity}</Badge>
        </Card>
    );
}

export default function GiftBoxPage() {
  const totalGifts = mockGifts.reduce((sum, gift) => sum + gift.count, 0);

  return (
    <div className="container py-8">
      <PageHeader
        title="My Gift Box"
        description="A collection of all the virtual gifts you've received from the community, each with its own value."
      />

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Inventory Summary</CardTitle>
           <CardDescription>You have received a total of <span className="font-bold text-primary">{totalGifts}</span> gifts!</CardDescription>
        </CardHeader>
        <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
                {mockGifts.map(gift => (
                    <GiftCard key={gift.name} gift={gift} />
                ))}
                 {/* Placeholder for empty state */}
                {mockGifts.length === 0 && (
                    <div className="col-span-full flex flex-col items-center justify-center text-center p-12 bg-muted rounded-lg">
                        <Gift className="h-16 w-16 text-muted-foreground mb-4" />
                        <h3 className="text-xl font-bold">Your Gift Box is Empty</h3>
                        <p className="text-muted-foreground">Create amazing content to receive gifts from your fans!</p>
                    </div>
                )}
            </div>
        </CardContent>
      </Card>
    </div>
  );
}
