'use client';

import { useState, useEffect, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import Link from 'next/link';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { generateMusicFromText } from '@/ai/flows';
import { Music, Mic, MicOff, AlertCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

// Check for SpeechRecognition API
const SpeechRecognition =
  (typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition));

const formSchema = z.object({
  description: z.string().min(10, 'Please provide a more detailed description (at least 10 characters).'),
  style: z.string().optional(),
  mood: z.string().optional(),
  tempo: z.string().optional(),
});

export default function MusicGeneratorPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [activeRecordingField, setActiveRecordingField] = useState<keyof z.infer<typeof formSchema> | null>(null);
  
  const recognitionRef = useRef<any>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      description: '',
      style: '',
      mood: '',
      tempo: 'medium',
    },
  });

  useEffect(() => {
    if (!SpeechRecognition) {
      toast({
        title: 'Browser Not Supported',
        description: 'Voice input is not supported in your browser. Please use Chrome or Edge.',
        variant: 'destructive',
      });
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      if (activeRecordingField) {
        form.setValue(activeRecordingField, transcript, { shouldValidate: true });
      }
      handleToggleRecording(null); // Stop recording after result
    };
    
    recognition.onerror = (event: any) => {
        toast({
            title: 'Speech Recognition Error',
            description: `Error: ${event.error}. Please check microphone permissions.`,
            variant: 'destructive',
        });
        setIsRecording(false);
        setActiveRecordingField(null);
    }

    recognitionRef.current = recognition;
  }, [toast, activeRecordingField, form]);

  const handleToggleRecording = (fieldName: keyof z.infer<typeof formSchema> | null) => {
    if (isRecording && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsRecording(false);
      setActiveRecordingField(null);
    } else if (fieldName) {
      if (recognitionRef.current) {
        setActiveRecordingField(fieldName);
        setIsRecording(true);
        recognitionRef.current.start();
      } else {
         toast({ title: 'Voice input not available.', variant: 'destructive' });
      }
    }
  };


  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setResult(null);
    setError(null);

    const fullDescription = `
      ${values.description}
      Style: ${values.style || 'any'}.
      Mood: ${values.mood || 'any'}.
      Tempo: ${values.tempo || 'medium'}.
    `;

    try {
      const response = await generateMusicFromText({ description: fullDescription });
      setResult(response.musicDataUri);
      toast({
        title: 'Music Generated!',
        description: 'Your new track is ready to play.',
      });
    } catch (err: any) {
      console.error(err);
      const isCreditError = err.message.includes('Insufficient credits');
      setError(
        isCreditError
          ? "You don't have enough credits for this action."
          : 'An unexpected error occurred. Please try again.'
      );
      toast({
        title: 'An error occurred.',
        description: isCreditError ? 'Please purchase more credits to continue.' : 'Failed to generate music. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }
  
  const renderMicButton = (fieldName: keyof z.infer<typeof formSchema>) => (
    <Button 
        type="button" 
        variant="ghost" 
        size="icon"
        onClick={() => handleToggleRecording(fieldName)}
        className={cn("absolute right-2 top-9 h-8 w-8", isRecording && activeRecordingField === fieldName && "bg-destructive text-destructive-foreground")}
        disabled={!SpeechRecognition || (isRecording && activeRecordingField !== fieldName)}
    >
        {isRecording && activeRecordingField === fieldName ? <MicOff className="h-4 w-4"/> : <Mic className="h-4 w-4"/>}
    </Button>
  );

  return (
    <div className="container py-8">
      <PageHeader
        title="AI Music Generator"
        description="Describe the music you want to create—by typing or by voice—and let our AI compose it for you."
      />

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Describe Your Music</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Main Idea</FormLabel>
                    <div className="relative">
                        <FormControl>
                          <Textarea
                            placeholder="e.g., An epic orchestral piece for a movie trailer, with powerful drums and a choir."
                            {...field}
                          />
                        </FormControl>
                        {renderMicButton('description')}
                    </div>
                    <FormDescription>
                        Be as descriptive as you can. Mention instruments, genre, and feeling.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                    control={form.control}
                    name="style"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>Style/Genre</FormLabel>
                         <div className="relative">
                            <FormControl>
                                <Input placeholder="e.g., Lofi hip-hop, cinematic, pop" {...field} />
                            </FormControl>
                            {renderMicButton('style')}
                        </div>
                    </FormItem>
                    )}
                />
                 <FormField
                    control={form.control}
                    name="mood"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>Mood</FormLabel>
                        <div className="relative">
                            <FormControl>
                                <Input placeholder="e.g., Happy, melancholic, energetic" {...field} />
                            </FormControl>
                            {renderMicButton('mood')}
                        </div>
                    </FormItem>
                    )}
                />
                 <FormField
                    control={form.control}
                    name="tempo"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>Tempo</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                                <SelectTrigger>
                                <SelectValue placeholder="Select tempo" />
                                </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                                <SelectItem value="slow">Slow</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="fast">Fast</SelectItem>
                            </SelectContent>
                        </Select>
                    </FormItem>
                    )}
                />
              </div>
                {error && (
                    <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Generation Failed</AlertTitle>
                    <AlertDescription>
                        {error}
                        {error.includes('credits') && (
                        <Button asChild variant="link" className="p-0 h-auto ml-2">
                            <Link href="/dashboard/premium">Purchase Credits</Link>
                        </Button>
                        )}
                    </AlertDescription>
                    </Alert>
                )}
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading || isRecording}>
                {isLoading ? <LoadingSpinner className="mr-2 h-4 w-4" /> : <Music className="mr-2 h-4 w-4" />}
                {isLoading ? 'Generating...' : 'Generate Music (5 Credits)'}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>

      {result && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Your Generated Track</CardTitle>
          </CardHeader>
          <CardContent>
            <audio controls src={result} className="w-full">
              Your browser does not support the audio element.
            </audio>
          </CardContent>
           <CardFooter>
            <Button asChild>
                <a href={result} download="ai_generated_music.mp3">Download Track</a>
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
