'use client';

import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Swords, Users, Dices, Crown } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface Game {
  title: string;
  description: string;
  icon: LucideIcon | ((props: any) => JSX.Element);
  playerCount: string;
  status: 'available' | 'coming_soon';
}

const games: Game[] = [
  {
    title: 'منچ (Mensch)',
    description: 'بازی کلاسیک و خاطره‌انگیز منچ برای سرگرمی و رقابت با دوستان.',
    icon: Users,
    playerCount: '۲-۴ نفره',
    status: 'coming_soon',
  },
  {
    title: 'تخته نرد (Backgammon)',
    description: 'در این بازی استراتژیک و شانسی با حریفان خود رقابت کنید.',
    icon: Dices,
    playerCount: '۲ نفره',
    status: 'coming_soon',
  },
  {
    title: 'حکم (Hokm)',
    description: 'محبوب‌ترین بازی کارتی گروهی، با قابلیت بازی دو و چهار نفره.',
    icon: Crown,
    playerCount: '۲ و ۴ نفره',
    status: 'coming_soon',
  },
  {
    title: 'شطرنج (Chess)',
    description: 'مهارت‌های استراتژیک خود را در بازی شاهان به چالش بکشید.',
    icon: (props) => (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M15.3 2.7a2.5 2.5 0 0 1 2.4 3.3L15 12H9l-1.3-2.7a2.5 2.5 0 0 1 2.4-3.3c.1 0 .2 0 .3.1Z"/>
            <path d="M7 11h8.5"/>
            <path d="M7 11v5a2 2 0 0 0 2 2h3"/>
            <path d="M5 11v.5A1.5 1.5 0 0 0 6.5 13H8"/>
        </svg>
    ),
    playerCount: '۲ نفره',
    status: 'coming_soon',
  },
  {
    title: 'بیلیارد (8-Ball Pool)',
    description: 'بازی کلاسیک و محبوب بیلیارد برای رقابت با دوستان و سایر بازیکنان.',
    icon: (props) => (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" stroke="none" {...props}>
        <circle cx="12" cy="12" r="10" />
      </svg>
    ),
    playerCount: '۲ و ۴ نفره',
    status: 'coming_soon',
  },
];


function GameCard({ game }: { game: Game }) {
    const Icon = game.icon;
    return (
        <Card className="flex flex-col">
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div className="flex items-center gap-4">
                        <Icon className="h-10 w-10 text-primary" />
                        <div>
                            <CardTitle className="font-headline text-2xl">{game.title}</CardTitle>
                            <CardDescription>{game.playerCount}</CardDescription>
                        </div>
                    </div>
                     {game.status === 'coming_soon' && <Badge variant="secondary">به زودی</Badge>}
                </div>
            </CardHeader>
            <CardContent className="flex-grow">
                <p className="text-muted-foreground">{game.description}</p>
            </CardContent>
            <CardContent>
                 <Button className="w-full" disabled={game.status === 'coming_soon'}>
                    {game.status === 'coming_soon' ? 'منتظر باشید...' : 'بازی کنید'}
                </Button>
            </CardContent>
        </Card>
    )
}


export default function GameCenterPage() {
  return (
    <div className="container py-8">
      <PageHeader
        title="مرکز بازی آفرینا"
        description="با دوستان خود بازی‌های کلاسیک و محبوب را تجربه کنید و امتیاز کسب کنید."
      />
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {games.map((game) => (
            <GameCard key={game.title} game={game} />
        ))}
      </div>
    </div>
  );
}
