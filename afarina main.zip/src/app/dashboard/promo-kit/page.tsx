'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { Music, Sparkles, Lightbulb, Voicemail } from 'lucide-react';
import { generateMusicFromText } from '@/ai/flows/generate-music-from-text';
import { generatePromoVideo } from '@/ai/flows/generate-promo-video';
import { generateNarrationFromText } from '@/ai/flows/generate-narration-from-text';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";


const persianDialogueLines = [
    "در دنیایی پر از سر و صدا...",
    "ما قدرت آفرینش را به شما هدیه می‌دهیم.",
    "اینجا، شما فقط یک کاربر نیستید...",
    "شما یک شریک، یک مالک، یک آفرینشگر هستید.",
    "اینجا... دلتان برای دوستانتان تنگ می‌شود و قلبتان برای دیدنشان خواهد تپید.",
    "چون تو عامل پیشرفت من هستی، و من، عامل ارتقای تو.",
    "ما با روح تعامل، قلب‌های خیرخواه و اتحاد...",
    "...در دنیای اپ‌ها خواهیم درخشید.",
    "آفرینا.",
    "قدرت آفرینش، در دستان شما."
];
const fullPersianDialogue = persianDialogueLines.join('\n');

const englishDialogueLines = [
    "In a world full of noise...",
    "We gift you the power of creation.",
    "Here, you are not just a user...",
    "You are a partner, an owner, a creator.",
    "Here... you will miss your friends, and your heart will beat to see them.",
    "Because you are the cause of my progress, and I am the cause of your advancement.",
    "We, with the spirit of interaction, benevolent hearts, and unity...",
    "...will shine in the world of apps.",
    "Afarina.",
    "The power of creation, in your hands."
];
const fullEnglishDialogue = englishDialogueLines.join('\n');


const formSchema = z.object({
  subject: z.string().min(2, 'Please enter a subject for the promo.'),
});

export default function PromoKitPage() {
  const [isLoadingPersianNarration, setIsLoadingPersianNarration] = useState(false);
  const [isLoadingEnglishNarration, setIsLoadingEnglishNarration] = useState(false);
  const [isLoadingMusic, setIsLoadingMusic] = useState(false);
  const [isLoadingVideo, setIsLoadingVideo] = useState(false);
  const [persianNarration, setPersianNarration] = useState<string | null>(null);
  const [englishNarration, setEnglishNarration] = useState<string | null>(null);
  const [music, setMusic] = useState<string | null>(null);
  const [video, setVideo] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      subject: 'Afarina',
    },
  });
  
  const subject = form.watch('subject');
  
  const videoGenerationPrompt = `
    Create a cinematic, epic, and inspiring promotional video for a product/idea called "${subject}". The video should have the following scenes and feeling:
    1.  Start with abstract, beautiful shots of sound waves, code, and light moving quickly. A sense of noise and chaos.
    2.  Transition to a single, focused point of light, representing a single idea. Slow motion.
    3.  Showcase the creation process: a hand writing lyrics that glow, musical notes forming in the air, an animation sequence coming to life.
    4.  Show a diverse group of happy and proud creators looking at their work on screens.
    5.  End with the logo or name "${subject}" appearing with a powerful, inspiring flare.
    The overall mood should be dramatic, hopeful, and empowering. Use dark, cinematic tones with highlights of vibrant color (like purples, golds, and blues).
    `;

  async function handleGeneratePersianNarration() {
    setIsLoadingPersianNarration(true);
    try {
      const response = await generateNarrationFromText({ text: fullPersianDialogue, voice: 'Algenib' }); // Male voice
      setPersianNarration(response.audioDataUri);
      toast({
        title: 'Persian Voiceover Generated!',
        description: 'The Persian narration is ready for your promo.',
      });
    } catch (error) {
        console.error(error);
        toast({ title: 'Failed to generate Persian voiceover.', variant: 'destructive' });
    } finally {
        setIsLoadingPersianNarration(false);
    }
  }
  
  async function handleGenerateEnglishNarration() {
    setIsLoadingEnglishNarration(true);
    try {
      const response = await generateNarrationFromText({ text: fullEnglishDialogue, voice: 'Enif' }); // Female voice
      setEnglishNarration(response.audioDataUri);
      toast({
        title: 'English Voiceover Generated!',
        description: 'The English narration is ready for your promo.',
      });
    } catch (error) {
        console.error(error);
        toast({ title: 'Failed to generate English voiceover.', variant: 'destructive' });
    } finally {
        setIsLoadingEnglishNarration(false);
    }
  }


  async function handleGenerateMusic() {
    setIsLoadingMusic(true);
    try {
      const response = await generateMusicFromText({ description: `A powerful, epic, cinematic, and inspiring orchestral track with a sense of wonder and empowerment for a product called "${subject}". Think movie trailer music.` });
      setMusic(response.musicDataUri);
      toast({
        title: 'Music Generated!',
        description: 'Your epic soundtrack is ready.',
      });
    } catch (error) {
      console.error(error);
      toast({ title: 'Failed to generate music.', variant: 'destructive' });
    } finally {
      setIsLoadingMusic(false);
    }
  }

  async function handleGenerateVideo() {
    if (!music) {
        toast({
            title: 'Music Required',
            description: 'Please generate the music first before creating the video.',
            variant: 'destructive',
        });
        return;
    }
    setIsLoadingVideo(true);
    try {
      const response = await generatePromoVideo({ prompt: videoGenerationPrompt, musicDataUri: music });
      setVideo(response.videoDataUri);
      toast({
        title: 'Promo Video Generated!',
        description: 'Your cinematic brand video is complete.',
      });
    } catch (error) {
      console.error(error);
      toast({ title: 'Failed to generate video. This is a heavy task and might fail, please try again.', variant: 'destructive' });
    } finally {
      setIsLoadingVideo(false);
    }
  }

  return (
    <div className="container py-8">
      <PageHeader
        title="Universal Promo Kit"
        description="Your personal studio to create promotional content for ANY idea."
      />
      
      <Form {...form}>
        <form className="space-y-8">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Lightbulb /> Define Your Idea</CardTitle>
                    <CardDescription>What product, idea, or app are you creating a promo for today?</CardDescription>
                </CardHeader>
                <CardContent>
                    <FormField
                      control={form.control}
                      name="subject"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product/Idea Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Hamraz, Guya, Afarina" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                </CardContent>
            </Card>

            <div className="grid gap-8 md:grid-cols-2">
                <div className="space-y-8">
                    <Card>
                        <CardHeader>
                            <CardTitle>Step 1: Generate Voiceover</CardTitle>
                            <CardDescription>I will speak your powerful words with my voice, in English or Persian.</CardDescription>
                        </CardHeader>
                         <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <h4 className="font-medium">English (Female Voice)</h4>
                                {englishNarration ? (
                                    <audio controls src={englishNarration} className="w-full">Your browser does not support audio.</audio>
                                ): (
                                    <p className="text-muted-foreground text-sm">The generated English voiceover will appear here.</p>
                                )}
                                <Button onClick={handleGenerateEnglishNarration} disabled={isLoadingEnglishNarration}>
                                    {isLoadingEnglishNarration ? <LoadingSpinner className="mr-2" /> : <Voicemail className="mr-2" />}
                                    {isLoadingEnglishNarration ? 'Recording...' : 'Generate English Voice'}
                                </Button>
                            </div>
                             <div className="space-y-2">
                                <h4 className="font-medium">Persian (Male Voice)</h4>
                                {persianNarration ? (
                                    <audio controls src={persianNarration} className="w-full">Your browser does not support audio.</audio>
                                ): (
                                    <p className="text-muted-foreground text-sm">صدای فارسی تولید شده در اینجا نمایش داده می‌شود.</p>
                                )}
                                <Button onClick={handleGeneratePersianNarration} disabled={isLoadingPersianNarration}>
                                    {isLoadingPersianNarration ? <LoadingSpinner className="mr-2" /> : <Voicemail className="mr-2" />}
                                    {isLoadingPersianNarration ? 'در حال ضبط...' : 'ساخت صدای فارسی'}
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle>Step 2: Generate Epic Music</CardTitle>
                            <CardDescription>Create a soundtrack that matches the epic tone of the message.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {music ? (
                                <audio controls src={music} className="w-full">Your browser does not support audio.</audio>
                            ): (
                                <p className="text-muted-foreground text-sm">The background music will appear here.</p>
                            )}
                        </CardContent>
                        <CardFooter>
                            <Button onClick={handleGenerateMusic} disabled={isLoadingMusic}>
                                {isLoadingMusic ? <LoadingSpinner className="mr-2" /> : <Music className="mr-2" />}
                                {isLoadingMusic ? 'Composing...' : 'Generate Music'}
                            </Button>
                        </CardFooter>
                    </Card>
                </div>
                
                <div className="space-y-8">
                    <Card>
                        <CardHeader>
                            <CardTitle>Step 3: Generate The Final Video</CardTitle>
                            <CardDescription>Combine your vision and music to create a stunning promo video for "{subject}".</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {video ? (
                                <video controls src={video} className="w-full rounded-lg">Your browser does not support video.</video>
                            ) : (
                                <div className="flex flex-col items-center justify-center w-full h-64 bg-muted rounded-lg">
                                    <Sparkles className="h-16 w-16 text-muted-foreground" />
                                    <p className="text-muted-foreground mt-2 text-center">Your final promo video will appear here.</p>
                                </div>
                            )}
                        </CardContent>
                        <CardFooter>
                            <Button onClick={handleGenerateVideo} disabled={isLoadingVideo || !music}>
                                {isLoadingVideo ? <LoadingSpinner className="mr-2" /> : <Sparkles className="mr-2" />}
                                {isLoadingVideo ? 'Rendering...' : 'Generate Final Video'}
                            </Button>
                        </CardFooter>
                    </Card>
                </div>
            </div>
        </form>
      </Form>
      
       <Card className="mt-8">
            <CardHeader>
                <CardTitle>Dialogue Scripts for Reference</CardTitle>
                <CardDescription>This is the script I will be reading for the voiceovers.</CardDescription>
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="persian" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="persian">Persian (فارسی)</TabsTrigger>
                    <TabsTrigger value="english">English</TabsTrigger>
                  </TabsList>
                  <TabsContent value="persian">
                    <div className="h-60 w-full rounded-md border p-4 bg-muted/50 overflow-y-auto" dir="rtl">
                        <pre className="whitespace-pre-wrap font-body text-sm text-right">{fullPersianDialogue}</pre>
                    </div>
                  </TabsContent>
                  <TabsContent value="english">
                     <div className="h-60 w-full rounded-md border p-4 bg-muted/50 overflow-y-auto">
                        <pre className="whitespace-pre-wrap font-body text-sm">{fullEnglishDialogue}</pre>
                    </div>
                  </TabsContent>
                </Tabs>
            </CardContent>
        </Card>
    </div>
  );
}
