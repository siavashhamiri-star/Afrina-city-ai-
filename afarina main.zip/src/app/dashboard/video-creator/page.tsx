'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import Link from 'next/link';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { FileUploader } from '@/components/file-uploader';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { generateAnimatedMusicVideo } from '@/ai/flows';
import { Clapperboard, AlertCircle } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

const formSchema = z.object({
  musicDataUri: z.string().min(1, 'Please upload a music file.'),
  visualStyleDescription: z.string().min(10, 'Please provide a style description.'),
  imageUri: z.string().optional(),
});

export default function VideoCreatorPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      musicDataUri: '',
      visualStyleDescription: '',
      imageUri: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setResult(null);
    setError(null);
    try {
      const response = await generateAnimatedMusicVideo({
          ...values,
          imageStyleDescription: values.imageUri ? 'Use this image as a style reference for characters or scenery' : undefined
      });
      setResult(response.videoDataUri);
      toast({
        title: 'Video Generated!',
        description: 'Your new animated music video is ready.',
      });
    } catch (err: any) {
      console.error(err);
      const isCreditError = err.message.includes('Insufficient credits');
      setError(
        isCreditError
          ? "You don't have enough credits for this action. Video generation is expensive."
          : 'Failed to generate video. This can take a minute, so please try again.'
      );
      toast({
        title: 'An error occurred.',
        description: isCreditError ? 'Please purchase more credits to continue.' : 'Failed to generate video. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="container py-8">
      <PageHeader
        title="AI Animated Video Creator"
        description="Bring your music to life with a custom-animated video."
      />

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Create Your Video</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="musicDataUri"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>1. Upload Your Music</FormLabel>
                    <FormControl>
                      <FileUploader
                        file={field.value || null}
                        onFileChange={field.onChange}
                        clearFile={() => field.onChange('')}
                        accept={{ 'audio/*': ['.mp3', '.wav'] }}
                        maxSize={10 * 1024 * 1024} // 10MB
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="visualStyleDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>2. Describe the Visual Style</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="e.g., A watercolor animation of a couple dancing in the rain. 90s anime style. Claymation."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="imageUri"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>3. Upload a Reference Image (Optional)</FormLabel>
                    <FormControl>
                      <FileUploader
                        file={field.value || null}
                        onFileChange={field.onChange}
                        clearFile={() => field.onChange('')}
                        accept={{ 'image/*': ['.png', '.jpg', '.jpeg'] }}
                        maxSize={5 * 1024 * 1024} // 5MB
                      />
                    </FormControl>
                    <FormDescription>Upload a photo of a person or a style to influence the animation.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              {error && (
                    <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Generation Failed</AlertTitle>
                    <AlertDescription>
                        {error}
                        {error.includes('credits') && (
                        <Button asChild variant="link" className="p-0 h-auto ml-2">
                            <Link href="/dashboard/premium">Purchase Credits</Link>
                        </Button>
                        )}
                    </AlertDescription>
                    </Alert>
                )}
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading} size="lg">
                {isLoading ? <LoadingSpinner className="mr-2 h-4 w-4" /> : <Clapperboard className="mr-2 h-4 w-4" />}
                {isLoading ? 'Generating Video...' : 'Create Video (20 Credits)'}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>

      {result && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Your Animated Video</CardTitle>
          </CardHeader>
          <CardContent>
            <video controls src={result} className="w-full rounded-lg" >
              Your browser does not support the video tag.
            </video>
          </CardContent>
           <CardFooter>
            <Button asChild>
                <a href={result} download="ai_animated_video.mp4">Download Video</a>
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
