import { FeatureCard } from "@/components/feature-card";
import { PageHeader } from "@/components/page-header";
import { dashboardConfig } from "@/config/dashboard";
import { PlaceHolderImages } from "@/lib/placeholder-images";

export default function DashboardPage() {
  const features = dashboardConfig.sidebarNav.filter(item => item.href !== '/dashboard');

  return (
    <div className="container py-8">
      <PageHeader
        title="Creator Dashboard"
        description="Your central hub for AI-powered content creation. Select a tool to begin."
      />
      <div className="grid gap-6 sm:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
        {features.map((feature) => {
          const imageIdMap: { [key: string]: string } = {
            "/dashboard/vocal-remover": "vocal_remover",
            "/dashboard/music-generator": "music_generator",
            "/dashboard/lyric-generator": "lyric_generator",
            "/dashboard/narrative-writer": "narrative_writer",
            "/dashboard/ai-editor": "ai_editor",
            "/dashboard/ad-creator": "ad_creator",
            "/dashboard/song-creator": "landing_hero",
            "/dashboard/video-creator": "video_creator",
            "/dashboard/live-stream": "live_stream",
            "/dashboard/contests": "contests",
            "/dashboard/community": "community_hub",
            "/dashboard/comedy-queens-hub": "talent_hub",
            "/dashboard/promo-kit": "promo_kit",
            "/dashboard/hamraz": "hamraz",
            "/dashboard/guya": "guya",
            "/dashboard/audio-recorder": "audio_recorder",
            "/dashboard/library": "library",
            "/dashboard/gift-box": "gift_box",
            "/dashboard/karaoke": "vocal_remover",
            "/dashboard/premium": "premium_membership",
          };
          const image = PlaceHolderImages.find(p => p.id === imageIdMap[feature.href]);
          return (
            <FeatureCard
              key={feature.href}
              title={feature.title}
              href={feature.href}
              icon={feature.icon}
              image={image}
            />
          );
        })}
      </div>
    </div>
  );
}
