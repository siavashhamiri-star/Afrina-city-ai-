'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import Link from 'next/link';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { generateNarrationFromText } from '@/ai/flows';
import { Wand2, Download, AlertCircle } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';


const formSchema = z.object({
  text: z.string().min(1, 'Please enter some text to generate narration.'),
  voice: z.string().optional(),
});

export default function AiEditorPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      text: '',
      voice: 'Algenib',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setResult(null);
    setError(null);
    try {
      const response = await generateNarrationFromText(values);
      setResult(response.audioDataUri);
      toast({
        title: 'Narration Generated!',
        description: 'Your audio is ready to play.',
      });
    } catch (err: any) {
      console.error(err);
      const isCreditError = err.message.includes('Insufficient credits');
      setError(
        isCreditError
          ? "You don't have enough credits for this action."
          : 'An unexpected error occurred. Please try again.'
      );
      toast({
        title: 'An error occurred.',
        description: isCreditError ? 'Please purchase more credits to continue.' : 'Failed to generate narration. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }
  
  // Note: These voices are examples. The actual available voices might differ.
  const voices = [
      { id: 'Algenib', name: 'Algenib (Male)' },
      { id: 'Achernar', name: 'Achernar (Male)' },
      { id: 'Enif', name: 'Enif (Female)' },
      { id: 'Hadar', name: 'Hadar (Female)' },
  ]

  return (
    <div className="container py-8">
      <PageHeader
        title="AI Voice Editor"
        description="Just speak or write, and let the AI edit your content for you. Starting with Text-to-Speech."
      />

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Generate Narration from Text</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="text"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your Script</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="e.g., Hello, welcome to my podcast. Today we'll be talking about..."
                        className="min-h-[150px]"
                        {...field}
                      />
                    </FormControl>
                     <FormDescription>
                        Enter the text you want to convert into speech.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                    control={form.control}
                    name="voice"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>Voice</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                                <SelectTrigger>
                                <SelectValue placeholder="Select a voice" />
                                </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                                {voices.map(voice => (
                                    <SelectItem key={voice.id} value={voice.id}>{voice.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <FormDescription>
                            Choose the voice for your narration.
                        </FormDescription>
                    </FormItem>
                    )}
                />
                 {error && (
                    <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Generation Failed</AlertTitle>
                    <AlertDescription>
                        {error}
                        {error.includes('credits') && (
                        <Button asChild variant="link" className="p-0 h-auto ml-2">
                            <Link href="/dashboard/premium">Purchase Credits</Link>
                        </Button>
                        )}
                    </AlertDescription>
                    </Alert>
                )}
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? <LoadingSpinner className="mr-2 h-4 w-4" /> : <Wand2 className="mr-2 h-4 w-4" />}
                {isLoading ? 'Generating...' : 'Generate Audio (2 Credits)'}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>

      {result && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Your Generated Audio</CardTitle>
          </CardHeader>
          <CardContent>
            <audio controls src={result} className="w-full">
              Your browser does not support the audio element.
            </audio>
          </CardContent>
           <CardFooter>
            <Button asChild>
                <a href={result} download="ai_generated_audio.wav">
                    <Download className="mr-2 h-4 w-4" />
                    Download Audio
                </a>
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
