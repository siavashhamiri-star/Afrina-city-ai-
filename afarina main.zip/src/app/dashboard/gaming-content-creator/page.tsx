'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { generateGamingContent, GamingContentTypeSchema } from '@/ai/flows/generate-gaming-content';
import { Gamepad2 } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';

const formSchema = z.object({
  gameName: z.string().min(1, 'Please enter a game name.'),
  contentType: GamingContentTypeSchema,
  customPrompt: z.string().optional(),
});

const contentTypes = [
    { value: 'review', label: 'Game Review' },
    { value: 'funny_moments_script', label: 'Funny Moments Script' },
    { value: 'lore_summary', label: 'Lore Summary' },
    { value: 'top_10_list', label: 'Top 10 List' },
    { value: 'beginner_guide', label: "Beginner's Guide" },
    { value: 'custom', label: 'Custom Request' },
];

export default function GamingContentCreatorPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      gameName: '',
      contentType: 'custom',
      customPrompt: '',
    },
  });

  const selectedContentType = form.watch('contentType');

  async function onSubmit(values: z.infer<typeof formSchema>) {
    if ((values.contentType === 'top_10_list' || values.contentType === 'custom') && !values.customPrompt) {
        form.setError('customPrompt', { type: 'manual', message: 'Please describe your specific request.' });
        return;
    }
    
    setIsLoading(true);
    setResult(null);
    try {
      const response = await generateGamingContent(values);
      setResult(response.content);
      toast({
        title: 'Gaming Content Generated!',
        description: 'Your new content is ready for your channel.',
      });
    } catch (error: any) {
      console.error(error);
      toast({
        title: 'An error occurred.',
        description: error.message || 'Failed to generate content. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="container py-8">
      <PageHeader
        title="AI Gaming Content Creator"
        description="Generate scripts, reviews, and ideas for your gaming channel in seconds."
      />

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Describe Your Content</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="gameName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Game Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Elden Ring, Baldur's Gate 3, Fortnite" {...field} />
                    </FormControl>
                     <FormDescription>The name of the video game you're focusing on.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="contentType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Content Type</FormLabel>
                     <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                            <SelectTrigger>
                            <SelectValue placeholder="Select a content type" />
                            </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                            {contentTypes.map(type => (
                                <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                     <FormDescription>Choose the kind of content you want to create.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
               {(selectedContentType === 'top_10_list' || selectedContentType === 'custom') && (
                 <FormField
                    control={form.control}
                    name="customPrompt"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>
                          {selectedContentType === 'top_10_list' ? 'Top 10 List Topic' : 'Your Custom Request'}
                        </FormLabel>
                        <FormControl>
                            <Textarea
                                placeholder={
                                  selectedContentType === 'top_10_list' 
                                  ? "e.g., Hardest Bosses, Secret Locations, Beginner Mistakes" 
                                  : "e.g., A video script about the funniest glitches in the game, or a top 5 list of the best starting characters."
                                }
                                {...field}
                                className="min-h-[150px]"
                            />
                        </FormControl>
                        <FormDescription>Describe your topic or request in detail. The more specific you are, the better the result.</FormDescription>
                        <FormMessage />
                    </FormItem>
                    )}
                />
               )}
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading} size="lg">
                {isLoading ? <LoadingSpinner className="mr-2 h-4 w-4" /> : <Gamepad2 className="mr-2 h-4 w-4" />}
                {isLoading ? 'Generating...' : 'Create Content'}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>

      {result && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Generated Gaming Content</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96 w-full rounded-md border p-4">
                <pre className="whitespace-pre-wrap font-body text-sm">{result}</pre>
            </ScrollArea>
          </CardContent>
           <CardFooter>
                <Button onClick={() => navigator.clipboard.writeText(result)}>
                    Copy to Clipboard
                </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
