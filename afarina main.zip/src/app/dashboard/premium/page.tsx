'use client';

import { useState, useEffect } from 'react';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { getUserCredits, addCredits } from '@/services/credit-service';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useUser } from '@/firebase/auth/use-user';
import { Sparkles, Gem, CreditCard, Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function PremiumPage() {
  const [credits, setCredits] = useState<number | null>(null);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [isLoadingCredits, setIsLoadingCredits] = useState(true);
  const { user } = useUser();
  const { toast } = useToast();

  useEffect(() => {
    async function fetchCredits() {
      if (!user) return;
      setIsLoadingCredits(true);
      try {
        const userCredits = await getUserCredits();
        setCredits(userCredits);
      } catch (error) {
        console.error('Failed to fetch credits', error);
        toast({
          title: 'Error',
          description: 'Could not fetch your credit balance.',
          variant: 'destructive',
        });
      } finally {
        setIsLoadingCredits(false);
      }
    }
    fetchCredits();
  }, [user, toast]);

  const handlePurchase = async () => {
    setIsPurchasing(true);
    try {
      await addCredits(100);
      const newCredits = await getUserCredits();
      setCredits(newCredits);
      toast({
        title: 'Purchase Successful!',
        description: '100 credits have been added to your account.',
      });
    } catch (error) {
      console.error('Failed to purchase credits', error);
      toast({
        title: 'Purchase Failed',
        description: 'There was an error processing your purchase. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsPurchasing(false);
    }
  };

  return (
    <div className="container py-8">
      <PageHeader
        title="Credits & Billing"
        description="Manage your credits to use Afarina's AI creative tools."
      />

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Buy Credits</CardTitle>
            <CardDescription>
              Purchase credits to continue using AI features once your free monthly credits are used up.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Card className="bg-primary/10">
              <CardHeader className="text-center">
                <Gem className="mx-auto h-12 w-12 text-primary mb-4" />
                <CardTitle className="font-headline text-3xl">Credit Pack</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-5xl font-bold font-headline">100</p>
                <p className="text-muted-foreground">credits</p>
                <p className="text-2xl font-semibold mt-4">$5.00</p>
              </CardContent>
              <CardFooter>
                <Button size="lg" className="w-full" onClick={handlePurchase} disabled={isPurchasing}>
                  {isPurchasing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CreditCard className="mr-2 h-4 w-4" />}
                  {isPurchasing ? 'Processing...' : 'Purchase Now'}
                </Button>
              </CardFooter>
            </Card>
          </CardContent>
        </Card>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Your Balance</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              {isLoadingCredits ? (
                <LoadingSpinner className="h-10 w-10 mx-auto" />
              ) : (
                <>
                  <p className="text-6xl font-bold font-headline">{credits ?? 'N/A'}</p>
                  <p className="text-muted-foreground">Available Credits</p>
                </>
              )}
            </CardContent>
          </Card>
          <Alert>
            <Sparkles className="h-4 w-4" />
            <AlertTitle>Free Monthly Credits</AlertTitle>
            <AlertDescription>
              All users receive 100 free credits at the beginning of each month. Purchased credits do not expire.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    </div>
  );
}
