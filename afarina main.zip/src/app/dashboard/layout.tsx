'use client';

import { SidebarNav } from "@/components/sidebar-nav";
import { dashboardConfig } from "@/config/dashboard";
import { SiteHeader } from "@/components/site-header";
import { FirebaseProvider } from "@/firebase/provider";
import { initializeFirebase } from "@/firebase";
import { useUser } from "@/firebase/auth/use-user";
import { LoadingSpinner } from "@/components/loading-spinner";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect } from "react";

const { firebaseApp, firestore, auth } = initializeFirebase();

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const { user, loading } = useUser();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const isGuestPage = pathname === '/dashboard/hamraz' && searchParams.get('guest') === 'true';

  useEffect(() => {
    if (!loading && !user && !isGuestPage) {
      router.push('/login');
    }
  }, [user, loading, router, isGuestPage]);


  if (loading) {
      return (
          <div className="flex h-screen items-center justify-center">
              <LoadingSpinner className="h-10 w-10"/>
          </div>
      )
  }

  if (!user && !isGuestPage) {
      return null;
  }
  
  // If it's a guest viewing the Hamraz page, we let the page handle its own layout.
  if (isGuestPage) {
    return (
       <FirebaseProvider firebaseApp={firebaseApp} auth={auth} firestore={firestore}>
          {children}
       </FirebaseProvider>
    )
  }


  return (
    <FirebaseProvider firebaseApp={firebaseApp} auth={auth} firestore={firestore}>
      <div className="flex min-h-screen flex-col">
        <SiteHeader />
        <div className="container flex-1 items-start md:grid md:grid-cols-[220px_minmax(0,1fr)] md:gap-6 lg:grid-cols-[240px_minmax(0,1fr)] lg:gap-10">
          <aside className="fixed top-16 z-30 -ml-2 hidden h-[calc(100vh-4rem)] w-full shrink-0 md:sticky md:block">
            <div className="relative overflow-hidden h-full py-6 pr-6 lg:py-8">
              <SidebarNav items={dashboardConfig.sidebarNav} />
            </div>
          </aside>
          <main className="flex w-full flex-col overflow-hidden">{children}</main>
        </div>
      </div>
    </FirebaseProvider>
  );
}