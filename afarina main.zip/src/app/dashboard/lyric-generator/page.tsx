'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import Link from 'next/link';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { generateLyrics } from '@/ai/flows';
import { FileText, AlertCircle } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

const formSchema = z.object({
  prompt: z.string().min(10, 'Please provide a more detailed prompt (at least 10 characters).'),
});

export default function LyricGeneratorPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      prompt: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setResult(null);
    setError(null);
    try {
      const response = await generateLyrics(values.prompt);
      setResult(response);
      toast({
        title: 'Lyrics Generated!',
        description: 'Your new song lyrics are ready.',
      });
    } catch (err: any) {
      console.error(err);
      const isCreditError = err.message.includes('Insufficient credits');
      setError(
        isCreditError
          ? "You don't have enough credits for this action."
          : 'An unexpected error occurred. Please try again.'
      );
      toast({
        title: 'An error occurred.',
        description: isCreditError ? 'Please purchase more credits to continue.' : 'Failed to generate lyrics. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="container py-8">
      <PageHeader
        title="AI Lyric Generator"
        description="Tell the AI what your song is about, and it will write the lyrics for you."
      />

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Describe Your Song's Theme</CardTitle>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="prompt"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Song Prompt</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="e.g., A sad song about a long-lost love, remembering happy moments in a rainy city."
                        className="min-h-[150px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              {error && (
                    <Alert variant="destructive" className="mt-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Generation Failed</AlertTitle>
                    <AlertDescription>
                        {error}
                        {error.includes('credits') && (
                        <Button asChild variant="link" className="p-0 h-auto ml-2">
                            <Link href="/dashboard/premium">Purchase Credits</Link>
                        </Button>
                        )}
                    </AlertDescription>
                    </Alert>
                )}
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? <LoadingSpinner className="mr-2 h-4 w-4" /> : <FileText className="mr-2 h-4 w-4" />}
                {isLoading ? 'Writing...' : 'Generate Lyrics (1 Credit)'}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>

      {result && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Generated Lyrics</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-72 w-full rounded-md border p-4">
              <pre className="whitespace-pre-wrap font-body text-sm">{result}</pre>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
