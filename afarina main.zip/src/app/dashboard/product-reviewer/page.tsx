'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { generateProductReview } from '@/ai/flows/generate-product-review';
import { Box } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

const formSchema = z.object({
  productName: z.string().min(2, 'Please enter a valid product name.'),
  productCategory: z.string().min(2, 'Please enter a valid category.'),
});

export default function ProductReviewerPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      productName: '',
      productCategory: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setResult(null);
    try {
      const response = await generateProductReview(values);
      setResult(response.reviewScript);
      toast({
        title: 'Review Script Generated!',
        description: 'Your script for the product review is ready.',
      });
    } catch (error) {
      console.error(error);
      toast({
        title: 'An error occurred.',
        description: 'Failed to generate the review script. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="container py-8">
      <PageHeader
        title="AI Product Reviewer"
        description="Generate a complete unboxing, review, and promotion script for any tech product."
      />

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Describe the Product</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="productName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., iPhone 15 Pro, Dell XPS 15, Sony WH-1000XM5" {...field} />
                    </FormControl>
                    <FormDescription>Enter the exact name of the product you want to review.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="productCategory"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product Category</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Smartphone, Laptop, Headphones" {...field} />
                    </FormControl>
                    <FormDescription>Provide the general category of the product.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading} size="lg">
                {isLoading ? <LoadingSpinner className="mr-2 h-4 w-4" /> : <Box className="mr-2 h-4 w-4" />}
                {isLoading ? 'Writing...' : 'Generate Script'}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>

      {result && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Generated Review Script</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96 w-full rounded-md border p-4">
                <pre className="whitespace-pre-wrap font-body text-sm">{result}</pre>
            </ScrollArea>
          </CardContent>
           <CardFooter>
                <Button onClick={() => navigator.clipboard.writeText(result)}>
                    Copy to Clipboard
                </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
