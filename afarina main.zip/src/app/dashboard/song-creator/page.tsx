'use client';

import { PageHeader } from '@/components/page-header';
import { SongCreator } from '@/components/song-creator';

export default function SongCreatorPage() {
  return (
    <div className="container py-8">
      <PageHeader
        title="AI Song Creator"
        description="Create a complete song with lyrics, music, and an animated video in three simple steps."
      />
      <SongCreator />
    </div>
  );
}
