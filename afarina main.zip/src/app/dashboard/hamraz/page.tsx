'use client';

import { useState, useRef, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import Link from 'next/link';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';
import { SendHorizonal, Bot, LayoutDashboard, User } from 'lucide-react';
import { chatWithHamraz } from '@/ai/flows/chat-with-hamraz';
import { useUser } from '@/firebase/auth/use-user';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { useSearchParams } from 'next/navigation';
import GuestLayout from '@/app/guest-layout';


interface Message {
  role: 'user' | 'model';
  content: string;
}

const formSchema = z.object({
  message: z.string().min(1, 'Please enter a message.'),
});

function HamrazChat() {
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', content: 'Hello, I am Hamraz, your confidant. How are you feeling today? Or we could play a little word game if you like.' }
  ]);
  const { user } = useUser();
  const searchParams = useSearchParams();
  const isGuest = searchParams.get('guest') === 'true';

  const { toast } = useToast();
  const scrollAreaRef = useRef<HTMLDivElement>(null);


  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      message: '',
    },
  });

  useEffect(() => {
    if (scrollAreaRef.current) {
        const viewport = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
        if (viewport) {
             viewport.scrollTop = viewport.scrollHeight;
        }
    }
  }, [messages]);

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);

    const userMessage: Message = { role: 'user', content: values.message };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    form.reset();

    try {
      const historyForAI = messages.map(msg => ({ role: msg.role as 'user' | 'model' | 'tool', content: msg.content }));
      const response = await chatWithHamraz({
        message: values.message,
        history: historyForAI,
      });

      const hamrazResponse: Message = { role: 'model', content: response.response };
      setMessages([...newMessages, hamrazResponse]);

    } catch (error) {
      console.error(error);
      toast({
        title: 'An error occurred.',
        description: 'Failed to get a response from Hamraz. Please try again.',
        variant: 'destructive',
      });
      setMessages(messages);
    } finally {
      setIsLoading(false);
    }
  }
  
  const userInitial = user?.displayName ? user.displayName.charAt(0).toUpperCase() : (user?.email ? user.email.charAt(0).toUpperCase() : '?');


  return (
     <div className="container py-8 flex flex-col h-[calc(100vh-6rem)]">
      <div className="flex justify-between items-start">
        <PageHeader
          title="Hamraz - Your Confidant"
          description="A safe and calm space to share your thoughts, feelings, or play a simple game."
        />
        {!isGuest && (
            <Button asChild variant="outline">
                <Link href="/dashboard">
                    <LayoutDashboard className="mr-2 h-4 w-4" />
                    Back to Dashboard
                </Link>
            </Button>
        )}
         {isGuest && (
            <Button asChild variant="outline">
                <Link href="/">
                    <LayoutDashboard className="mr-2 h-4 w-4" />
                    Back to Homepage
                </Link>
            </Button>
        )}
      </div>

    <Card className="flex-1 flex flex-col mt-8">
        <CardHeader>
            <CardTitle>Conversation</CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-hidden">
            <ScrollArea className="h-full" ref={scrollAreaRef}>
                 <div className="space-y-6 pr-4">
                    {messages.map((message, index) => (
                        <div key={index} className={cn("flex items-start gap-3", message.role === 'user' ? 'justify-end' : 'justify-start')}>
                            {message.role === 'model' && (
                                <Avatar className="h-9 w-9 border-2 border-primary/50">
                                    <div className="bg-primary/20 h-full w-full flex items-center justify-center">
                                         <Bot className="h-5 w-5 text-primary" />
                                    </div>
                                </Avatar>
                            )}
                            <div className={cn("max-w-md rounded-xl px-4 py-3 text-sm", 
                                message.role === 'user' ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-muted rounded-bl-none'
                            )}>
                               <p className="whitespace-pre-wrap">{message.content}</p>
                            </div>
                             {message.role === 'user' && (
                                 <Avatar className="h-9 w-9">
                                    {isGuest ? (
                                        <AvatarFallback>
                                            <User className="h-5 w-5" />
                                        </AvatarFallback>
                                    ) : (
                                        <>
                                            <AvatarImage src={user?.photoURL || ''} alt={user?.displayName || ''} />
                                            <AvatarFallback>{userInitial}</AvatarFallback>
                                        </>
                                    )}
                                </Avatar>
                            )}
                        </div>
                    ))}
                    {isLoading && (
                         <div className="flex items-start gap-3 justify-start">
                            <Avatar className="h-9 w-9 border-2 border-primary/50">
                                <div className="bg-primary/20 h-full w-full flex items-center justify-center">
                                     <Bot className="h-5 w-5 text-primary" />
                                </div>
                            </Avatar>
                            <div className="bg-muted rounded-xl px-4 py-3 text-sm rounded-bl-none flex items-center">
                               <LoadingSpinner className="h-4 w-4" />
                            </div>
                        </div>
                    )}
                 </div>
            </ScrollArea>
        </CardContent>
        <CardFooter className="pt-6 border-t">
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="flex w-full items-center gap-2">
                    <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                        <FormItem className="flex-1">
                            <FormControl>
                            <Input placeholder="Type your message here, or say 'let's play a game'..." {...field} autoComplete="off" />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    <Button type="submit" disabled={isLoading} size="icon">
                        <SendHorizonal className="h-4 w-4" />
                        <span className="sr-only">Send Message</span>
                    </Button>
                </form>
            </Form>
        </CardFooter>
    </Card>

    </div>
  )
}

export default function HamrazPage() {
    const { user, loading } = useUser();
    const searchParams = useSearchParams();
    const isGuest = searchParams.get('guest') === 'true';

    if (loading) {
        return <div className="flex justify-center items-center h-screen"><LoadingSpinner /></div>;
    }

    if (isGuest && !user) {
        return (
            <GuestLayout>
                <HamrazChat />
            </GuestLayout>
        )
    }

    if (!user && !isGuest) {
        // This should redirect to login if not a guest
        // You can add a redirect here if needed
        return <div className="flex justify-center items-center h-screen">Please <a href="/login" className="underline ml-1">log in</a>.</div>;
    }

    return <HamrazChat />
}
