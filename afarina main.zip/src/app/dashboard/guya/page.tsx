'use client';

import { useState, useEffect, useRef } from 'react';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { Mic, MicOff, Bot, User, Play } from 'lucide-react';
import { cn } from '@/lib/utils';
import { chatWithHamraz } from '@/ai/flows/chat-with-hamraz';
import { generateNarrationFromText } from '@/ai/flows/generate-narration-from-text';
import { useUser } from '@/firebase/auth/use-user';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';


// Check for SpeechRecognition API
const SpeechRecognition =
  (typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition));

interface GuyaMessage {
  role: 'user' | 'model';
  text: string;
  audioUri?: string;
}

export default function GuyaPage() {
  const [isRecording, setIsRecording] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [conversation, setConversation] = useState<GuyaMessage[]>([
      { role: 'model', text: 'Hello, I am ready to listen. What is on your mind?' }
  ]);
  const [transcript, setTranscript] = useState('');
  const recognitionRef = useRef<any>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { user } = useUser();

  const { toast } = useToast();

  useEffect(() => {
    if (!SpeechRecognition) {
      toast({
        title: 'Browser Not Supported',
        description: 'Your browser does not support the Web Speech API. Please use Chrome or Edge.',
        variant: 'destructive',
      });
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'fa-IR'; // Or 'en-US' or any other supported language

    recognition.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }
      setTranscript(finalTranscript + interimTranscript);
    };
    
    recognition.onerror = (event: any) => {
        toast({
            title: 'Speech Recognition Error',
            description: `Error: ${event.error}. Please check your microphone permissions.`,
            variant: 'destructive',
        });
        console.error('Speech recognition error:', event);
        setIsRecording(false);
    }

    recognitionRef.current = recognition;
  }, [toast]);

  const handleToggleRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
      if (transcript.trim()) {
        handleSendMessage(transcript);
      }
    } else {
      setTranscript('');
      recognitionRef.current?.start();
      setIsRecording(true);
    }
  };

  const handleSendMessage = async (message: string) => {
    if (!message.trim()) return;

    const userMessage: GuyaMessage = { role: 'user', text: message };
    setConversation(prev => [...prev, userMessage]);
    setIsLoading(true);
    setTranscript('');

    try {
        const historyForAI = conversation.map(msg => ({ role: msg.role, content: msg.text }));
        
        // Get AI text response
        const chatResponse = await chatWithHamraz({
            message: message,
            history: historyForAI,
        });
        const aiText = chatResponse.response;

        // Get AI audio response
        const narrationResponse = await generateNarrationFromText({ text: aiText });
        const aiAudioUri = narrationResponse.audioDataUri;
        
        const aiMessage: GuyaMessage = { role: 'model', text: aiText, audioUri: aiAudioUri };
        setConversation(prev => [...prev, aiMessage]);

        // Automatically play the AI response
        if (audioRef.current) {
            audioRef.current.src = aiAudioUri;
            audioRef.current.play();
        }

    } catch (error) {
        console.error('Error in conversation flow:', error);
        toast({
            title: 'An error occurred',
            description: 'Failed to get a response from the AI. Please try again.',
            variant: 'destructive',
        });
        // Remove the user's message if the API call fails to avoid a broken conversation
        setConversation(prev => prev.slice(0, -1));
    } finally {
        setIsLoading(false);
    }
  };
  
  const playAudio = (audioUri: string) => {
      if(audioRef.current) {
          audioRef.current.src = audioUri;
          audioRef.current.play();
      }
  }

  const userInitial = user?.displayName ? user.displayName.charAt(0).toUpperCase() : (user?.email ? user.email.charAt(0).toUpperCase() : '?');

  return (
    <div className="container py-8">
      <PageHeader
        title="Guya - Voice Assistant"
        description="Speak your mind. Have a natural voice conversation with your creative AI partner."
      />
      <Card>
        <CardHeader>
          <CardTitle>Conversation</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 min-h-[300px]">
            {conversation.map((msg, index) => (
                <div key={index} className={cn("flex items-start gap-3", msg.role === 'user' ? 'justify-end' : 'justify-start')}>
                     {msg.role === 'model' && (
                        <Avatar className="h-9 w-9 border-2 border-primary/50">
                             <div className="bg-primary/20 h-full w-full flex items-center justify-center">
                                <Bot className="h-5 w-5 text-primary" />
                             </div>
                        </Avatar>
                    )}
                    <div className={cn("max-w-md rounded-xl px-4 py-3 text-sm", 
                        msg.role === 'user' ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-muted rounded-bl-none'
                    )}>
                       <p>{msg.text}</p>
                       {msg.audioUri && (
                           <Button variant="ghost" size="icon" className="mt-2 h-8 w-8" onClick={() => playAudio(msg.audioUri)}>
                               <Play className="h-4 w-4" />
                           </Button>
                       )}
                    </div>
                     {msg.role === 'user' && (
                        <Avatar className="h-9 w-9">
                            <AvatarImage src={user?.photoURL || ''} alt={user?.displayName || ''} />
                            <AvatarFallback>{userInitial}</AvatarFallback>
                        </Avatar>
                    )}
                </div>
            ))}
             {isRecording && (
                <div className="flex justify-end items-start gap-3">
                    <div className="max-w-md rounded-xl px-4 py-3 text-sm bg-primary/80 text-primary-foreground italic rounded-br-none">
                       <p>{transcript || "Listening..."}</p>
                    </div>
                     <Avatar className="h-9 w-9">
                        <AvatarImage src={user?.photoURL || ''} alt={user?.displayName || ''} />
                        <AvatarFallback>{userInitial}</AvatarFallback>
                    </Avatar>
                </div>
            )}
            {isLoading && (
                 <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9 border-2 border-primary/50">
                         <div className="bg-primary/20 h-full w-full flex items-center justify-center">
                            <Bot className="h-5 w-5 text-primary" />
                         </div>
                    </Avatar>
                    <LoadingSpinner />
                </div>
            )}
        </CardContent>
        <CardFooter className="flex flex-col items-center gap-4 border-t pt-6">
            <Button 
                onClick={handleToggleRecording} 
                disabled={!SpeechRecognition || isLoading}
                size="lg" 
                className={cn("rounded-full w-20 h-20 transition-all duration-300", isRecording && "bg-destructive hover:bg-destructive/90 scale-110")}
            >
                {isRecording ? <MicOff className="h-8 w-8" /> : <Mic className="h-8 w-8" />}
            </Button>
            <p className="text-sm text-muted-foreground">
                {isRecording ? "Tap to stop recording and send" : "Tap to start speaking"}
            </p>
        </CardFooter>
      </Card>
      <audio ref={audioRef} className="hidden" />
    </div>
  );
}

// Add this to your global types or a suitable place
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}
