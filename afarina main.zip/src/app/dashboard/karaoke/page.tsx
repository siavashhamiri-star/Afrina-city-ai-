
'use client';

import { useState } from 'react';
import Image from 'next/image';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useUser } from '@/firebase/auth/use-user';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { ListMusic, Mic, Send, Heart, Flame, Laugh, Gift, Music2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

// Mock Data
const currentPerformer = {
  id: 'user2',
  name: 'Sara',
  avatar: 'https://i.pravatar.cc/150?u=user2',
  song: 'My Heart Will Go On',
  artist: 'Celine Dion',
};

const queue = [
  { id: 'user3', name: 'Mina', avatar: 'https://i.pravatar.cc/150?u=user3', song: 'Someone Like You' },
  { id: 'user4', name: 'Kian', avatar: 'https://i.pravatar.cc/150?u=user4', song: 'Bohemian Rhapsody' },
  { id: 'user5', name: 'Nazanin', avatar: 'https://i.pravatar.cc/150?u=user5', song: 'Gole Yakh' },
];

const comments = [
  { id: 'user1', name: 'Alireza', avatar: 'https://i.pravatar.cc/150?u=user1', text: 'Wow, what a voice! Go Sara! 👏👏' },
  { id: 'user4', name: 'Kian', avatar: 'https://i.pravatar.cc/150?u=user4', text: 'Amazing performance!' },
  { id: 'user3', name: 'Mina', avatar: 'https://i.pravatar.cc/150?u=user3', text: 'You are a star! 🌟' },
];

export default function KaraokeRoomPage() {
  const { user } = useUser();
  const [newComment, setNewComment] = useState('');
  const [giftProgress, setGiftProgress] = useState(60); // Mock progress

  const userInitial = user?.displayName ? user.displayName.charAt(0).toUpperCase() : (user?.email ? user.email.charAt(0).toUpperCase() : 'U');

  return (
    <div className="container py-8">
      <PageHeader
        title="Karaoke Room"
        description="Sing your heart out, listen to others, and have fun with the community."
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Stage & Interactions Column */}
        <div className="lg:col-span-2 space-y-8">
          {/* Stage Card */}
          <Card>
            <CardHeader>
              <CardTitle>Now Performing</CardTitle>
              <div className="pt-2 space-y-1">
                 <Progress value={giftProgress} className="h-2" />
                 <p className="text-xs text-muted-foreground text-center">Room Gift Goal</p>
              </div>
            </CardHeader>
            <CardContent className="flex flex-col items-center text-center">
              <Avatar className="h-24 w-24 mb-4 border-4 border-primary shadow-lg">
                <AvatarImage src={currentPerformer.avatar} alt={currentPerformer.name} />
                <AvatarFallback>{currentPerformer.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <h3 className="text-2xl font-bold font-headline">{currentPerformer.name}</h3>
              <p className="text-muted-foreground">is singing</p>
              <p className="text-xl font-semibold mt-2">"{currentPerformer.song}"</p>
              <p className="text-sm text-muted-foreground">by {currentPerformer.artist}</p>
              <div className="w-full bg-muted rounded-full h-2.5 mt-6">
                <div className="bg-primary h-2.5 rounded-full w-[60%]"></div>
              </div>
            </CardContent>
            <CardFooter className="flex-col items-center gap-4">
                 <p className="text-sm text-muted-foreground">Send a reaction!</p>
                 <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon" className="rounded-full h-12 w-12 hover:bg-red-100 dark:hover:bg-red-900/50">
                        <Heart className="h-6 w-6 text-red-500" />
                    </Button>
                    <Button variant="outline" size="icon" className="rounded-full h-12 w-12 hover:bg-orange-100 dark:hover:bg-orange-900/50">
                        <Flame className="h-6 w-6 text-orange-500" />
                    </Button>
                    <Button variant="outline" size="icon" className="rounded-full h-12 w-12 hover:bg-yellow-100 dark:hover:bg-yellow-900/50">
                        <Laugh className="h-6 w-6 text-yellow-500" />
                    </Button>
                     <Button size="lg" className="h-12 rounded-full ml-4">
                        <Gift className="mr-2 h-6 w-6" />
                        Send Gift
                    </Button>
                 </div>
            </CardFooter>
          </Card>

          {/* Comments/Chat Card */}
          <Card>
            <CardHeader>
              <CardTitle>Live Chat</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-48 pr-4">
                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="flex items-start gap-3">
                       <Avatar className="h-8 w-8">
                            <AvatarImage src={comment.avatar} alt={comment.name} />
                            <AvatarFallback>{comment.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                            <p className="font-semibold text-sm">{comment.name}</p>
                            <p className="text-sm bg-secondary rounded-lg px-3 py-2 mt-1">{comment.text}</p>
                        </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
             <CardFooter>
                <div className="flex w-full items-center gap-2">
                    <Avatar className="h-9 w-9">
                        <AvatarImage src={user?.photoURL || ''} alt={user?.displayName || ''} />
                        <AvatarFallback>{userInitial}</AvatarFallback>
                    </Avatar>
                    <Input 
                        placeholder="Say something nice..." 
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                    />
                    <Button size="icon">
                        <Send className="h-4 w-4" />
                    </Button>
                </div>
             </CardFooter>
          </Card>
        </div>

        {/* Queue & Actions Column */}
        <div className="space-y-8">
          {/* Queue Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ListMusic />
                Performance Queue
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {queue.map((item, index) => (
                  <div key={item.id} className="flex items-center justify-between p-2 rounded-md bg-secondary">
                     <div className="flex items-center gap-3">
                        <Badge variant="default" className="text-lg">#{index + 1}</Badge>
                         <Avatar className="h-10 w-10">
                            <AvatarImage src={item.avatar} alt={item.name} />
                            <AvatarFallback>{item.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                            <p className="font-semibold">{item.name}</p>
                            <p className="text-xs text-muted-foreground truncate">{item.song}</p>
                        </div>
                     </div>
                  </div>
                ))}
                {queue.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">The queue is empty. It's your time to shine!</p>}
              </div>
            </CardContent>
          </Card>
          
           {/* Join Queue Card */}
          <Card>
             <CardHeader>
                <CardTitle>Your Turn!</CardTitle>
                <CardDescription>Select a song and join the queue to perform.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <label className="text-sm font-medium">Select a Song</label>
                    <Button variant="outline" className="w-full justify-start mt-2">
                        <Music2 className="mr-2 h-4 w-4" />
                        Browse Songbook...
                    </Button>
                </div>
            </CardContent>
            <CardFooter>
                 <Button className="w-full" size="lg">
                    <Mic className="mr-2 h-4 w-4" />
                    Join the Queue
                </Button>
            </CardFooter>
          </Card>

        </div>
      </div>
    </div>
  );
}
