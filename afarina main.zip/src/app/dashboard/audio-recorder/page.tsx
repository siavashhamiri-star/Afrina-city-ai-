'use client';

import { useState, useRef } from 'react';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { Mic, MicOff, Disc, Download, Play } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

type RecordingStatus = 'idle' | 'recording' | 'stopped';

export default function AudioRecorderPage() {
  const [status, setStatus] = useState<RecordingStatus>('idle');
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  
  const { toast } = useToast();

  const startRecording = async () => {
    if (status === 'recording') return;

    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setStream(mediaStream);
      setStatus('recording');
      
      const mediaRecorder = new MediaRecorder(mediaStream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      
      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);
        setStatus('stopped');
        mediaStream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      toast({
        title: 'Recording Started',
        description: 'Speak into your microphone.',
      });

    } catch (err) {
      console.error('Error accessing microphone:', err);
      toast({
        title: 'Microphone Error',
        description: 'Could not access microphone. Please check your permissions and try again.',
        variant: 'destructive',
      });
      setStatus('idle');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && status === 'recording') {
      mediaRecorderRef.current.stop();
      // onstop handler will set the status and URL
      toast({
        title: 'Recording Stopped',
        description: 'Your audio has been processed.',
      });
    }
  };
  
  const resetRecording = () => {
      setAudioUrl(null);
      setStatus('idle');
      audioChunksRef.current = [];
  }

  return (
    <div className="container py-8">
      <PageHeader
        title="Afarina Audio Recorder"
        description="Capture your musical ideas, voice notes, or any sound directly in your browser."
      />
      
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Disc className="h-6 w-6 text-primary" />
            Audio Recorder
          </CardTitle>
           <CardDescription>Record, preview, and download your audio clips.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 flex flex-col items-center">
            
            <div className="relative w-40 h-40">
                <div className={cn("absolute inset-0 rounded-full bg-muted flex items-center justify-center transition-all duration-300", 
                    status === 'recording' && 'bg-destructive/20 animate-pulse'
                )}>
                   <Button 
                        onClick={status === 'recording' ? stopRecording : startRecording} 
                        size="lg"
                        variant={status === 'recording' ? 'destructive' : 'default'}
                        className="rounded-full w-24 h-24 shadow-lg"
                    >
                        {status === 'recording' ? <MicOff className="h-10 w-10"/> : <Mic className="h-10 w-10"/>}
                    </Button>
                </div>
            </div>

            <p className="text-sm text-muted-foreground">
                {status === 'idle' && 'Tap the microphone to start recording.'}
                {status === 'recording' && 'Recording... Tap to stop.'}
                {status === 'stopped' && 'Recording finished. Preview below.'}
            </p>

            {audioUrl && (
                <div className="w-full space-y-4 pt-4">
                     <Alert>
                        <Play className="h-4 w-4" />
                        <AlertTitle>Preview Recording</AlertTitle>
                        <AlertDescription>
                            Listen to your recording before downloading.
                        </AlertDescription>
                    </Alert>
                    <audio controls src={audioUrl} className="w-full"></audio>
                </div>
            )}
        </CardContent>
        <CardFooter className="justify-end gap-2">
            {audioUrl && (
                <>
                    <Button variant="outline" onClick={resetRecording}>Record Again</Button>
                    <Button asChild>
                        <a href={audioUrl} download={`afarina-recording-${new Date().toISOString()}.wav`}>
                            <Download className="mr-2" /> Download
                        </a>
                    </Button>
                </>
            )}
        </CardFooter>
      </Card>
    </div>
  );
}
