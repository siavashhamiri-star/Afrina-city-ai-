'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { discoverComedyTalent, ComedyTalent } from '@/ai/flows/discover-comedy-talent';
import { Award, Crown, HelpingHand, Laugh, Users, Zap, ShieldCheck, Handshake } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertTitle } from '@/components/ui/alert';

function TalentCard({ talent }: { talent: ComedyTalent }) {
  return (
    <Card className="flex flex-col">
      <CardHeader className="flex flex-row items-center gap-4">
        <Avatar className="h-16 w-16">
          <AvatarImage src={talent.avatarUrl} alt={talent.name} />
          <AvatarFallback>{talent.name.charAt(0)}</AvatarFallback>
        </Avatar>
        <div>
          <CardTitle className="text-2xl font-headline flex items-center gap-2">
             <Badge className="text-xl font-bold" variant="secondary">#{talent.rank}</Badge>
            {talent.name}
          </CardTitle>
          <div className="flex items-center gap-2 mt-1">
             <Badge variant="default" className="flex items-center gap-1">
                <ShieldCheck className="h-3 w-3" />
                <span className="font-bold">{talent.grade}</span>
             </Badge>
            <CardDescription>{talent.contentTheme}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-grow space-y-4">
        <div className="flex justify-around text-center">
            <div>
                <p className="font-bold text-lg">{talent.followerCount.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">دنبال‌کنندگان</p>
            </div>
             <div>
                <p className="font-bold text-lg">%{talent.engagementRate * 100}</p>
                <p className="text-sm text-muted-foreground">نرخ تعامل</p>
            </div>
        </div>
        <p className="text-sm text-muted-foreground italic border-l-4 border-primary pl-4 py-2 bg-secondary/30">
          {talent.justification}
        </p>
      </CardContent>
      <div className="p-6 pt-0">
        <Button className="w-full">
            <Handshake className="mr-2 h-4 w-4" /> حمایت از این استعداد
        </Button>
      </div>
    </Card>
  );
}

export default function ComedyTalentHubPage() {
  const [isLoading, setIsLoading] = useState(true);
  const [talents, setTalents] = useState<ComedyTalent[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    async function fetchTalent() {
      setIsLoading(true);
      try {
        const response = await discoverComedyTalent();
        setTalents(response.talents);
      } catch (error) {
        console.error(error);
        toast({
          title: 'خطا در شناسایی استعدادها',
          description: 'مشکلی در ارتباط با هوش مصنوعی پیش آمده است. لطفاً دوباره تلاش کنید.',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    }
    fetchTalent();
  }, [toast]);

  const features = [
      {
          icon: <Crown className="w-8 h-8 text-amber-500" />,
          title: "کشف و معرفی",
          description: "هوش مصنوعی ما به طور مداوم در حال تحلیل و شناسایی استعدادهای نوظهور در حوزه کمدی از ایران و سراسر جهان است."
      },
      {
          icon: <HelpingHand className="w-8 h-8 text-green-500" />,
          title: "جذب اسپانسر",
          description: "ما به طور فعال استعدادهای برتر و کمدین‌های گمنام را به برندها و اسپانسرهای معتبر معرفی کرده و به شما در مسیر کسب درآمد کمک می‌کنیم."
      },
      {
          icon: <Award className="w-8 h-8 text-blue-500" />,
          title: "جوایز و حمایت ویژه",
          description: "علاوه بر فرصت‌های اسپانسری، جوایز نقدی، اشتراک‌های پریمیوم و حمایت‌های تبلیغاتی ویژه‌ای برای استعدادهای برتر در نظر گرفته شده است."
      }
  ]

  return (
    <div className="container py-8">
      <PageHeader
        title="مرکز استعدادهای کمدی"
        description="سکویی برای کشف، حمایت و معرفی کمدین‌های خلاق. استفاده از آواتار یا تصویر غیرواقعی برای حفظ حریم خصوصی، کاملاً پذیرفته و محترم است."
      />
      
      <Card className="mb-8 bg-gradient-to-r from-primary/10 to-secondary/10">
        <CardHeader>
            <CardTitle className="flex items-center gap-2"><Laugh className="text-primary" /> چشم‌انداز استراتژیک ما</CardTitle>
        </CardHeader>
        <CardContent>
            <p className="text-muted-foreground">
                ما باور داریم که طنز یک زبان جهانی و یکی از پرطرفدارترین انواع محتوا در اینترنت است. "مرکز استعدادهای کمدی" به عنوان موتور رشد پلتفرم ما عمل می‌کند. با ایجاد انگیزه برای کشف و حمایت از استعدادهای کمدی گمنام در ایران و جهان، ما به طور مداوم محتوای طنز، جذاب و پربیننده برای پلتفرم خود تولید می‌کنیم. این محتوای رایگان و انحصاری، باعث جذب مخاطب انبوه شده و رشد همه‌جانبه برنامه را تضمین می‌کند. موفقیت شما، موفقیت جامعه ماست.
            </p>
        </CardContent>
      </Card>
      
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {features.map((feature, index) => (
                 <div key={index} className="flex flex-col items-center text-center p-6 rounded-lg border bg-card hover:shadow-lg transition-shadow">
                  {feature.icon}
                  <h3 className="text-xl font-bold font-headline mt-4 mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
            ))}
        </div>

      <Card className="mb-12 text-center">
        <CardHeader>
          <div className="flex justify-center items-center gap-4">
              <Handshake className="w-10 h-10 text-primary" />
              <CardTitle className="font-headline text-3xl">اینجا رقبا رفیق شما هستند</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-lg text-muted-foreground">در آفرینا، رقابت به معنای رشد متقابل است. هر لایک، هر کامنت و هر حمایت از دیگران، به پیشرفت کل جامعه—و خود شما—کمک می‌کند. تو عامل پیشرفت من، و من عامل ارتقای تو.</p>
        </CardContent>
      </Card>


      <h2 className="text-3xl font-headline font-bold text-center mb-8 flex items-center justify-center gap-3">
        <Zap className="text-primary" /> استعدادهای در حال رشد فصل
      </h2>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
             <Card key={i}>
                <CardHeader className="flex flex-row items-center gap-4">
                    <Skeleton className="h-16 w-16 rounded-full" />
                    <div className="space-y-2">
                        <Skeleton className="h-6 w-32" />
                        <Skeleton className="h-4 w-24" />
                    </div>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex justify-around">
                        <Skeleton className="h-10 w-16" />
                        <Skeleton className="h-10 w-16" />
                    </div>
                    <Skeleton className="h-16 w-full" />
                </CardContent>
                 <div className="p-6 pt-0">
                    <Skeleton className="h-10 w-full" />
                </div>
             </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {talents.map(talent => (
            <TalentCard key={talent.id} talent={talent} />
          ))}
        </div>
      )}
    </div>
  );
}
