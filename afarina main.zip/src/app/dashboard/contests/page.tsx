'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { FileUploader } from '@/components/file-uploader';
import { submitContestEntry, ContestTypeSchema } from '@/ai/flows/submit-contest-entry';
import { Upload, Mic, Video, Music, Users, Star, Award } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const formSchema = z.object({
  entryDataUri: z.string().min(1, 'Please upload your file.'),
});

type ContestKey = 'dubbing' | 'animation' | 'remix';

const contestDetails: Record<ContestKey, any> = {
    dubbing: {
        title: "چالش دوبله و هم‌آوایی",
        icon: <Mic className="h-8 w-8 text-primary" />,
        description: "یک کلیپ انیمیشن صامت یا یک آهنگ بی‌کلام را دریافت کرده و با صدای خود به آن زندگی ببخشید. می‌توانید با خواننده اصلی دوئت کنید یا یک داستان جدید بسازید.",
        prizes: "بهترین دوبله‌ها برنده تجهیزات صوتی حرفه‌ای، اشتراک پریمیوم و شانس حضور در تبلیغات رسمی پلتفرم خواهند شد.",
        fileType: "audio/*",
        fileAccept: { 'audio/*': ['.mp3', '.wav'] },
        judging: "آثار بر اساس خلاقیت در صداپیشگی، синхронизация و کیفیت ضبط توسط هوش مصنوعی و رای کاربران داوری می‌شوند."
    },
    animation: {
        title: "مسابقه انیمیشن‌سازی",
        icon: <Video className="h-8 w-8 text-primary" />,
        description: "بهترین انیمیشن کوتاه خود را ارسال کنید. این می‌تواند 2D، 3D، استاپ موشن یا هر سبک دیگری باشد. یک داستان بگویید، یک جلوه بصری خلق کنید یا ما را بخندانید.",
        prizes: "برنده یک سال اشتراک پریمیوم، تبلیغ اثر در شبکه‌های اجتماعی ما و یک مصاحبه ویژه در وبلاگ ما را دریافت خواهد کرد.",
        fileType: "video/*",
        fileAccept: { 'video/*': ['.mp4', '.mov', '.webm'] },
        judging: "انیمیشن‌ها بر اساس داستان، کیفیت فنی، خلاقیت بصری و جذابیت کلی توسط هوش مصنوعی و کارشناسان ما ارزیابی می‌شوند."
    },
     remix: {
        title: "مسابقه ریمیکس تیمی",
        icon: <Music className="h-8 w-8 text-primary" />,
        description: "با یک هم‌تیمی (یک دی‌جی و یک تنظیم‌کننده) یک آهنگ معروف را ریمیکس کنید. خلاقیت خود را در تنظیم مجدد و ایجاد یک فضای جدید نشان دهید.",
        prizes: "تیم برنده یک جایزه نقدی، معرفی ویژه در صفحه اصلی و فرصت همکاری در یک پروژه رسمی را کسب خواهد کرد.",
        fileType: "audio/*",
        fileAccept: { 'audio/*': ['.mp3', '.wav'] },
        judging: "داوری به صورت ترکیبی است: ۵۰٪ امتیاز توسط هوش مصنوعی (بر اساس پیچیدگی، کیفیت و نوآوری) و ۵۰٪ بر اساس لایک و بازخورد اعضای جامعه آفرینا."
    }
}

function ContestCard({ contestKey }: { contestKey: ContestKey }) {
    const [isLoading, setIsLoading] = useState(false);
    const { toast } = useToast();
    const details = contestDetails[contestKey];

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: { entryDataUri: '' },
    });

    async function onSubmit(values: z.infer<typeof formSchema>) {
        setIsLoading(true);
        try {
        const response = await submitContestEntry({
            contestType: contestKey,
            entryDataUri: values.entryDataUri,
        });
        toast({
            title: 'ارسال موفقیت‌آمیز بود!',
            description: response.confirmationMessage,
        });
        form.reset();
        } catch (error) {
        console.error(error);
        toast({
            title: 'خطایی رخ داد.',
            description: 'ارسال اثر شما با مشکل مواجه شد. لطفاً دوباره تلاش کنید.',
            variant: 'destructive',
        });
        } finally {
        setIsLoading(false);
        }
    }

    return (
        <Card className="flex flex-col">
            <CardHeader>
                <div className="flex items-center gap-4">
                    {details.icon}
                    <CardTitle className="font-headline text-2xl">{details.title}</CardTitle>
                </div>
                <CardDescription className="pt-2">{details.description}</CardDescription>
            </CardHeader>
             <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col flex-grow">
                    <CardContent className="space-y-6 flex-grow">
                        <div>
                            <h4 className="font-semibold text-lg mb-2 flex items-center gap-2"><Star className="h-5 w-5 text-amber-500" /> جوایز</h4>
                            <p className="text-muted-foreground">{details.prizes}</p>
                        </div>
                         <div>
                            <h4 className="font-semibold text-lg mb-2 flex items-center gap-2"><Users className="h-5 w-5 text-blue-500" /> نحوه داوری</h4>
                            <p className="text-muted-foreground">{details.judging}</p>
                        </div>
                        <FormField
                            control={form.control}
                            name="entryDataUri"
                            render={({ field }) => (
                            <FormItem>
                                <FormLabel>فایل خود را آپلود کنید</FormLabel>
                                <FormControl>
                                <FileUploader
                                    file={field.value || null}
                                    onFileChange={field.onChange}
                                    clearFile={() => field.onChange('')}
                                    accept={details.fileAccept}
                                    maxSize={50 * 1024 * 1024} // 50MB
                                />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                            )}
                        />
                    </CardContent>
                    <CardFooter>
                        <Button type="submit" disabled={isLoading} size="lg" className="w-full">
                            {isLoading ? <LoadingSpinner className="mr-2 h-4 w-4" /> : <Upload className="mr-2 h-4 w-4" />}
                            {isLoading ? 'در حال ارسال...' : 'ارسال اثر'}
                        </Button>
                    </CardFooter>
                </form>
            </Form>
        </Card>
    )
}


export default function ContestsPage() {
  return (
    <div className="container py-8">
      <PageHeader
        title="مرکز مسابقات آفرینا"
        description="استعداد خود را در چالش‌های خلاقانه ما به نمایش بگذارید و جوایز شگفت‌انگیز ببرید!"
      />

       <Alert className="mb-8 border-primary/50 bg-primary/10">
          <Award className="h-4 w-4 text-primary" />
          <AlertTitle className="font-bold">قانون طلایی: امتیاز دو برابر برای تیم‌ها!</AlertTitle>
          <AlertDescription>
           تمام پروژه‌های تیمی، همکاری‌های خلاقانه و هم‌آوایی‌های مشترک در مسابقات، **امتیاز دو برابر** دریافت می‌کنند. با دوستان خود تیم تشکیل دهید تا سریع‌تر رشد کنید و جوایز بزرگتری ببرید!
          </AlertDescription>
        </Alert>

      <div className="grid gap-8 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
        {(Object.keys(contestDetails) as ContestKey[]).map((key) => (
            <ContestCard key={key} contestKey={key} />
        ))}
      </div>

    </div>
  );
}
