'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { generateImageFromText } from '@/ai/flows';
import { Image as ImageIcon, AlertCircle } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

const formSchema = z.object({
  type: z.enum(['logo', 'banner', 'ad'], { required_error: 'Please select a type.' }),
  description: z.string().min(10, 'Please provide a more detailed description (at least 10 characters).'),
  style: z.string().optional(),
});

export default function AdCreatorPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      description: '',
      style: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setResult(null);
    setError(null);

    const fullDescription = `
      A ${values.type} with the following description: ${values.description}.
      ${values.style ? `The desired style is: ${values.style}.` : ''}
    `;

    try {
      const response = await generateImageFromText({ description: fullDescription });
      setResult(response.imageDataUri);
      toast({
        title: 'Image Generated!',
        description: `Your new ${values.type} is ready.`,
      });
    } catch (err: any) {
      console.error(err);
      const isCreditError = err.message.includes('Insufficient credits');
      setError(
        isCreditError
          ? "You don't have enough credits for this action."
          : 'An unexpected error occurred. Please try again.'
      );
      toast({
        title: 'An error occurred.',
        description: isCreditError ? 'Please purchase more credits to continue.' : 'Failed to generate image. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="container py-8">
      <PageHeader
        title="AI Ad, Logo & Banner Creator"
        description="Describe the visual you need, and our AI will design it for you in seconds."
      />

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Design Your Visual</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>1. What do you want to create?</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                            <SelectTrigger>
                            <SelectValue placeholder="Select a type (e.g., Logo)" />
                            </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                            <SelectItem value="logo">Logo</SelectItem>
                            <SelectItem value="banner">Banner</SelectItem>
                            <SelectItem value="ad">Advertisement</SelectItem>
                        </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>2. Describe your visual</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="e.g., A minimalist logo for a coffee shop named 'Morning Brew', with a coffee bean icon. A vibrant banner for a summer sale with beach elements."
                        className="min-h-[150px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                        Be specific about colors, objects, text, and overall feeling.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                  control={form.control}
                  name="style"
                  render={({ field }) => (
                  <FormItem>
                      <FormLabel>3. Define the style (Optional)</FormLabel>
                      <FormControl>
                          <Input placeholder="e.g., Modern, vintage, cartoonish, 3D render, photographic" {...field} />
                      </FormControl>
                      <FormDescription>
                          Mention any artistic styles you prefer.
                      </FormDescription>
                  </FormItem>
                  )}
              />
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Generation Failed</AlertTitle>
                  <AlertDescription>
                    {error}
                    {error.includes('credits') && (
                      <Button asChild variant="link" className="p-0 h-auto ml-2">
                        <Link href="/dashboard/premium">Purchase Credits</Link>
                      </Button>
                    )}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading} size="lg">
                {isLoading ? <LoadingSpinner className="mr-2 h-4 w-4" /> : <ImageIcon className="mr-2 h-4 w-4" />}
                {isLoading ? 'Designing...' : 'Generate Image (3 Credits)'}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>

      {result && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Your Generated Image</CardTitle>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Image 
                src={result} 
                alt="Generated visual" 
                width={512} 
                height={512} 
                className="rounded-lg shadow-lg"
            />
          </CardContent>
           <CardFooter>
            <Button asChild>
                <a href={result} download="ai_generated_image.png">Download Image</a>
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
