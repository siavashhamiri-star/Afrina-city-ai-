'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import Link from 'next/link';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { FileUploader } from '@/components/file-uploader';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { removeVocalFromMusic } from '@/ai/flows';
import { MicVocal, AlertCircle } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

const formSchema = z.object({
  musicDataUri: z.string().min(1, 'Please upload a music file.'),
});

export default function VocalRemoverPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      musicDataUri: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setResult(null);
    setError(null);
    try {
      const response = await removeVocalFromMusic(values);
      setResult(response.vocalRemovedMusicDataUri);
      toast({
        title: 'Success!',
        description: 'Vocals have been removed from your music track.',
      });
    } catch (err: any) {
      console.error(err);
       const isCreditError = err.message.includes('Insufficient credits');
      setError(
        isCreditError
          ? "You don't have enough credits for this action."
          : 'An unexpected error occurred. Please try again.'
      );
      toast({
        title: 'An error occurred.',
        description: isCreditError ? 'Please purchase more credits to continue.' : 'Failed to remove vocals. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="container py-8">
      <PageHeader
        title="AI Vocal Remover"
        description="Upload a song to magically remove the vocals and get an instrumental track."
      />

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Upload Your Music</CardTitle>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="musicDataUri"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Music File</FormLabel>
                    <FormControl>
                      <FileUploader
                        file={field.value || null}
                        onFileChange={field.onChange}
                        clearFile={() => field.onChange('')}
                        accept={{ 'audio/*': ['.mp3', '.wav', '.ogg'] }}
                        maxSize={25 * 1024 * 1024} // 25MB
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
               {error && (
                    <Alert variant="destructive" className="mt-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Processing Failed</AlertTitle>
                    <AlertDescription>
                        {error}
                        {error.includes('credits') && (
                        <Button asChild variant="link" className="p-0 h-auto ml-2">
                            <Link href="/dashboard/premium">Purchase Credits</Link>
                        </Button>
                        )}
                    </AlertDescription>
                    </Alert>
                )}
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? <LoadingSpinner className="mr-2 h-4 w-4" /> : <MicVocal className="mr-2 h-4 w-4" />}
                {isLoading ? 'Processing...' : 'Remove Vocals (10 Credits)'}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>

      {result && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Your Instrumental Track</CardTitle>
          </CardHeader>
          <CardContent>
            <audio controls src={result} className="w-full">
              Your browser does not support the audio element.
            </audio>
          </CardContent>
          <CardFooter>
            <Button asChild>
                <a href={result} download="instrumental_track.mp3">Download Track</a>
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
