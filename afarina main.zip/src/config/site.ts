export type SiteConfig = typeof siteConfig

export const siteConfig = {
  name: "Afarina",
  description:
    "آفرینا: اکوسیستم دموکراتیک جهانی برای توانمندسازی مطلق آفرینشگران با مدل توزیع ۹۰/۱۰",
}
