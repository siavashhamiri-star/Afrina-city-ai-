import { DashboardConfig } from "@/types";

export const dashboardConfig: DashboardConfig = {
  sidebarNav: [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: "layoutDashboard",
    },
    {
      title: "My Library",
      href: "/dashboard/library",
      icon: "library"
    },
    {
      title: "Song Creator",
      href: "/dashboard/song-creator",
      icon: "star"
    },
    {
      title: "Video Creator",
      href: "/dashboard/video-creator",
      icon: "video"
    },
    {
      title: "Music Generator",
      href: "/dashboard/music-generator",
      icon: "music",
    },
    {
      title: "AI Voice Editor",
      href: "/dashboard/ai-editor",
      icon: "wand2",
    },
    {
      title: "Ad & Banner Creator",
      href: "/dashboard/ad-creator",
      icon: "image",
    },
    {
      title: "Vocal Remover",
      href: "/dashboard/vocal-remover",
      icon: "micVocal",
    },
    {
      title: "Narrative Writer",
      href: "/dashboard/narrative-writer",
      icon: "fileText",
    },
    {
      title: "Lyric Generator",
      href: "/dashboard/lyric-generator",
      icon: "fileText",
    },
    {
      title: "Hamraz",
      href: "/dashboard/hamraz",
      icon: "heart"
    },
     {
      title: "Credits & Billing",
      href: "/dashboard/premium",
      icon: "sparkles",
    },
  ],
};
