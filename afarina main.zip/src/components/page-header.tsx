interface PageHeaderProps {
  title: string;
  description: string;
}

export function PageHeader({ title, description }: PageHeaderProps) {
  return (
    <div className="mb-8">
      <h1 className="font-headline text-3xl md:text-4xl font-bold">{title}</h1>
      <p className="text-lg text-muted-foreground mt-2">{description}</p>
    </div>
  );
}
