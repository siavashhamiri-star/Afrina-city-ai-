'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { LoadingSpinner } from '@/components/loading-spinner';
import { useToast } from '@/hooks/use-toast';
import { generateLyrics, generateMusicFromText, generateAnimatedMusicVideo } from '@/ai/flows';
import { FileText, Music, Clapperboard, ArrowLeft, AlertCircle, CreditCard } from 'lucide-react';
import { ScrollArea } from './ui/scroll-area';
import { Input } from './ui/input';
import { Alert, AlertTitle, AlertDescription } from './ui/alert';
import Link from 'next/link';

const lyricsSchema = z.object({
  prompt: z.string().min(10, 'Please provide a more detailed prompt (at least 10 characters).'),
});

const musicSchema = z.object({
  style: z.string().optional(),
  mood: z.string().optional(),
});

const videoSchema = z.object({
  visualStyleDescription: z.string().min(10, 'Please provide a style description.'),
});

type Step = 'lyrics' | 'music' | 'video' | 'finished';

export function SongCreator() {
  const [step, setStep] = useState<Step>('lyrics');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const [lyrics, setLyrics] = useState('');
  const [musicDataUri, setMusicDataUri] = useState('');
  const [videoDataUri, setVideoDataUri] = useState('');

  const lyricsForm = useForm<z.infer<typeof lyricsSchema>>({
    resolver: zodResolver(lyricsSchema),
    defaultValues: { prompt: '' },
  });

  const musicForm = useForm<z.infer<typeof musicSchema>>({
    resolver: zodResolver(musicSchema),
    defaultValues: { style: '', mood: '' },
  });
  
  const videoForm = useForm<z.infer<typeof videoSchema>>({
    resolver: zodResolver(videoSchema),
    defaultValues: { visualStyleDescription: '' },
  });

  const handleApiCall = async (apiCall: () => Promise<any>, onSuccess: (response: any) => void) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiCall();
      onSuccess(response);
    } catch (err: any) {
      console.error(err);
      const isCreditError = err.message.includes('Insufficient credits');
      setError(
        isCreditError
          ? "You don't have enough credits for this action."
          : 'An unexpected error occurred. Please try again.'
      );
      toast({
        title: 'Error',
        description: isCreditError
          ? "Please purchase more credits to continue."
          : 'Failed to complete the request.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };


  async function onGenerateLyrics(values: z.infer<typeof lyricsSchema>) {
    await handleApiCall(
      () => generateLyrics(values.prompt),
      (response) => {
        setLyrics(response);
        toast({ title: 'Lyrics Generated!' });
        setStep('music');
      }
    );
  }

  async function onGenerateMusic(values: z.infer<typeof musicSchema>) {
    const description = `A song with the following lyrics: "${lyrics.substring(0, 200)}...". Style: ${values.style || 'any'}. Mood: ${values.mood || 'any'}.`;
    await handleApiCall(
      () => generateMusicFromText({ description }),
      (response) => {
        setMusicDataUri(response.musicDataUri);
        toast({ title: 'Music Generated!' });
        setStep('video');
      }
    );
  }

  async function onGenerateVideo(values: z.infer<typeof videoSchema>) {
    await handleApiCall(
      () => generateAnimatedMusicVideo({ musicDataUri, visualStyleDescription: values.visualStyleDescription }),
      (response) => {
        setVideoDataUri(response.videoDataUri);
        toast({ title: 'Video Generated!' });
        setStep('finished');
      }
    );
  }

  const renderError = () => {
    if (!error) return null;
    return (
        <Alert variant="destructive" className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Action Failed</AlertTitle>
            <AlertDescription>
                {error}
                {error.includes('credits') && (
                    <Button asChild variant="link" className="p-0 h-auto ml-2">
                        <Link href="/dashboard/premium">Purchase Credits</Link>
                    </Button>
                )}
            </AlertDescription>
        </Alert>
    );
  };


  const renderStep = () => {
    switch (step) {
      case 'lyrics':
        return (
          <Card>
            <CardHeader>
              <CardTitle>Step 1: Write Your Lyrics</CardTitle>
            </CardHeader>
            <Form {...lyricsForm}>
              <form onSubmit={lyricsForm.handleSubmit(onGenerateLyrics)}>
                <CardContent>
                  <FormField
                    control={lyricsForm.control}
                    name="prompt"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Song Theme</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="e.g., A happy song about a road trip with friends."
                            className="min-h-[150px]"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  {renderError()}
                </CardContent>
                <CardFooter>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? <LoadingSpinner /> : <FileText />}
                    {isLoading ? 'Writing...' : 'Generate Lyrics (1 Credit)'}
                  </Button>
                </CardFooter>
              </form>
            </Form>
          </Card>
        );
      case 'music':
        return (
          <Card>
            <CardHeader>
              <CardTitle>Step 2: Compose Your Music</CardTitle>
            </CardHeader>
            <Form {...musicForm}>
              <form onSubmit={musicForm.handleSubmit(onGenerateMusic)}>
                <CardContent className="space-y-4">
                   <ScrollArea className="h-48 w-full rounded-md border p-4 mb-4">
                     <h3 className="font-semibold mb-2">Your Lyrics:</h3>
                     <pre className="whitespace-pre-wrap font-body text-sm">{lyrics}</pre>
                   </ScrollArea>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     <FormField
                         control={musicForm.control}
                         name="style"
                         render={({ field }) => (
                         <FormItem>
                             <FormLabel>Style/Genre</FormLabel>
                             <FormControl>
                                 <Input placeholder="e.g., Pop, rock, electronic" {...field} />
                             </FormControl>
                         </FormItem>
                         )}
                     />
                      <FormField
                         control={musicForm.control}
                         name="mood"
                         render={({ field }) => (
                         <FormItem>
                             <FormLabel>Mood</FormLabel>
                             <FormControl>
                                 <Input placeholder="e.g., Upbeat, somber, epic" {...field} />
                             </FormControl>
                         </FormItem>
                         )}
                     />
                   </div>
                   {renderError()}
                </CardContent>
                <CardFooter className="justify-between">
                  <Button variant="outline" onClick={() => setStep('lyrics')}>
                    <ArrowLeft /> Back to Lyrics
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? <LoadingSpinner /> : <Music />}
                    {isLoading ? 'Composing...' : 'Generate Music (5 Credits)'}
                  </Button>
                </CardFooter>
              </form>
            </Form>
          </Card>
        );
      case 'video':
        return (
          <Card>
            <CardHeader>
              <CardTitle>Step 3: Create Your Animated Video</CardTitle>
            </CardHeader>
            <Form {...videoForm}>
              <form onSubmit={videoForm.handleSubmit(onGenerateVideo)}>
                <CardContent className="space-y-4">
                  <div>
                    <FormLabel>Your Song:</FormLabel>
                    <audio controls src={musicDataUri} className="w-full mt-2">
                        Your browser does not support the audio element.
                    </audio>
                  </div>
                  <FormField
                    control={videoForm.control}
                    name="visualStyleDescription"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Visual Style</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="e.g., 90s anime style, claymation, watercolor animation"
                            className="min-h-[100px]"
                            {...field}
                          />
                        </FormControl>
                         <FormDescription>Describe the look and feel of your video.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  {renderError()}
                </CardContent>
                <CardFooter className="justify-between">
                   <Button variant="outline" onClick={() => setStep('music')}>
                    <ArrowLeft /> Back to Music
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? <LoadingSpinner /> : <Clapperboard />}
                    {isLoading ? 'Animating...' : 'Generate Video (20 Credits)'}
                  </Button>
                </CardFooter>
              </form>
            </Form>
          </Card>
        );
      case 'finished':
        return (
             <Card className="mt-8">
              <CardHeader>
                <CardTitle>Your Song is Ready!</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-2">Final Video</h3>
                   <video controls src={videoDataUri} className="w-full rounded-lg" >
                    Your browser does not support the video tag.
                  </video>
                </div>
                 <div>
                    <h3 className="font-semibold mb-2">Lyrics</h3>
                    <ScrollArea className="h-40 w-full rounded-md border p-4">
                        <pre className="whitespace-pre-wrap font-body text-sm">{lyrics}</pre>
                    </ScrollArea>
                </div>
              </CardContent>
               <CardFooter className="justify-between">
                <Button variant="outline" onClick={() => {
                    setStep('lyrics');
                    setLyrics('');
                    setMusicDataUri('');
                    setVideoDataUri('');
                    lyricsForm.reset();
                    musicForm.reset();
                    videoForm.reset();
                    setError(null);
                }}>
                    Create Another Song
                </Button>
                <Button asChild>
                    <a href={videoDataUri} download="ai_song_video.mp4">Download Video</a>
                </Button>
              </CardFooter>
            </Card>
        );
    }
  };

  return <div className="max-w-4xl mx-auto">{renderStep()}</div>;
}
