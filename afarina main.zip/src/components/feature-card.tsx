import Link from "next/link";
import Image from "next/image";
import * as Icons from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { ImagePlaceholder } from "@/lib/placeholder-images";

interface FeatureCardProps {
  title: string;
  href: string;
  icon?: keyof typeof import("lucide-react");
  image?: ImagePlaceholder;
}

export function FeatureCard({ title, href, icon, image }: FeatureCardProps) {
  const Icon = icon ? Icons[icon as keyof typeof Icons] as React.ElementType : Icons.ArrowRight;

  return (
    <Card className="flex flex-col overflow-hidden transition-all hover:shadow-lg">
      {image && (
        <div className="aspect-video relative overflow-hidden">
          <Image
            src={image.imageUrl}
            alt={image.description}
            fill
            className="object-cover transition-transform duration-300 ease-in-out hover:scale-105"
            data-ai-hint={image.imageHint}
          />
        </div>
      )}
      <CardHeader className="flex-row items-center gap-4">
         <div className="bg-secondary p-3 rounded-md">
           <Icon className="h-6 w-6 text-primary" />
         </div>
        <CardTitle className="font-headline text-2xl">{title}</CardTitle>
      </CardHeader>
      <CardContent className="flex-grow flex justify-end items-end">
        <Button asChild className="w-full">
          <Link href={href}>Launch Tool</Link>
        </Button>
      </CardContent>
    </Card>
  );
}
