'use client';

import { useCallback } from 'react';
import { useDropzone, FileRejection } from 'react-dropzone';
import { UploadCloud, File as FileIcon, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface FileUploaderProps {
  onFileChange: (dataUri: string) => void;
  file: string | null;
  clearFile: () => void;
  accept: { [key: string]: string[] };
  maxSize: number; // in bytes
}

export function FileUploader({ onFileChange, file, clearFile, accept, maxSize }: FileUploaderProps) {
  const { toast } = useToast();

  const onDrop = useCallback((acceptedFiles: File[], fileRejections: FileRejection[]) => {
    if (fileRejections.length > 0) {
      fileRejections.forEach(({ errors }) => {
        errors.forEach(error => {
          toast({
            title: 'File Upload Error',
            description: error.message,
            variant: 'destructive',
          });
        });
      });
      return;
    }

    const uploadedFile = acceptedFiles[0];
    if (uploadedFile) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUri = e.target?.result as string;
        onFileChange(dataUri);
      };
      reader.readAsDataURL(uploadedFile);
    }
  }, [onFileChange, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept,
    maxSize,
    multiple: false,
  });

  if (file) {
    return (
      <div className="w-full p-4 border rounded-lg flex items-center justify-between bg-secondary">
        <div className="flex items-center gap-3">
          <FileIcon className="h-6 w-6 text-primary" />
          <p className="text-sm font-medium text-secondary-foreground truncate">File ready for processing</p>
        </div>
        <button onClick={clearFile} className="p-1 rounded-full hover:bg-muted">
          <X className="h-5 w-5" />
        </button>
      </div>
    );
  }

  return (
    <div
      {...getRootProps()}
      className={`w-full p-8 border-2 border-dashed rounded-lg text-center cursor-pointer transition-colors ${
        isDragActive ? 'border-primary bg-primary/10' : 'border-border hover:border-primary/50'
      }`}
    >
      <input {...getInputProps()} />
      <div className="flex flex-col items-center gap-2 text-muted-foreground">
        <UploadCloud className="h-10 w-10" />
        {isDragActive ? (
          <p className="font-semibold text-primary">Drop the file here...</p>
        ) : (
          <p>Drag & drop a file here, or click to select a file</p>
        )}
        <p className="text-xs">
          (Max file size: {maxSize / 1024 / 1024}MB)
        </p>
      </div>
    </div>
  );
}
