
'use client';

import Link from 'next/link';
import { getAuth, signOut } from 'firebase/auth';
import type { User } from 'firebase/auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Skeleton } from './ui/skeleton';
import { useRouter } from 'next/navigation';
import { useUser } from '@/firebase/auth/use-user';
import { Badge } from './ui/badge';
import { Sparkles, Star, Gem, TrendingUp, FolderHeart, Users, Home, Radio, BarChart, Handshake, Heart } from 'lucide-react';


interface UserNavProps {
  // User is now fetched from the hook
}

export function UserNav({ }: UserNavProps) {
  const { user, loading } = useUser();
  const router = useRouter();
  const auth = getAuth();

  // Mock data for points and premium status
  const userPoints = 1250;
  const isPremium = true;
  const userLevel = 15;

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      router.push('/');
    } catch (error) {
      console.error('Error signing out: ', error);
    }
  };

  if (loading) {
    return <Skeleton className="h-9 w-24" />;
  }

  if (!user) {
    return (
      <Button asChild>
        <Link href="/login">Login / Sign Up</Link>
      </Button>
    );
  }

  const userInitial = user.displayName ? user.displayName.charAt(0).toUpperCase() : (user.email ? user.email.charAt(0).toUpperCase() : '?');

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-8 w-8 rounded-full">
          <Avatar className="h-9 w-9">
            <AvatarImage src={user.photoURL || ''} alt={user.displayName || user.email || 'User'} />
            <AvatarFallback>{userInitial}</AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-2">
            <div className="flex items-center gap-2">
              <p className="text-sm font-medium leading-none">{user.displayName || 'User'}</p>
              {isPremium && <Badge variant="secondary" className="border-amber-500/50"><Gem className="h-3 w-3 mr-1 text-amber-500"/> VIP</Badge>}
            </div>
            <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
          </div>
        </DropdownMenuLabel>
        
        <DropdownMenuSeparator />

        <DropdownMenuGroup>
           <DropdownMenuItem onClick={() => router.push('/dashboard')}>
            <BarChart className="mr-2 h-4 w-4" />
            Dashboard
          </DropdownMenuItem>
           <DropdownMenuItem onClick={() => router.push('/dashboard/library')}>
             <FolderHeart className="mr-2 h-4 w-4" />
            My Library
          </DropdownMenuItem>
           <DropdownMenuItem onClick={() => router.push('/dashboard/hamraz')}>
             <Heart className="mr-2 h-4 w-4" />
            Hamraz - My Confidant
          </DropdownMenuItem>
        </DropdownMenuGroup>

        <DropdownMenuSeparator />

        <DropdownMenuGroup>
            <DropdownMenuLabel className="text-xs text-muted-foreground">Social</DropdownMenuLabel>
             <DropdownMenuItem onClick={() => router.push('/dashboard/community')}>
                <Users className="mr-2 h-4 w-4" />
                <span>My Friends</span>
            </DropdownMenuItem>
             <DropdownMenuItem onClick={() => router.push('/dashboard/radio')}>
                <Radio className="mr-2 h-4 w-4" />
                <span>Afarina Radio</span>
            </DropdownMenuItem>
             <DropdownMenuItem onClick={() => router.push('/dashboard/community')}>
                <Home className="mr-2 h-4 w-4" />
                <span>My Family</span>
            </DropdownMenuItem>
             <DropdownMenuItem onClick={() => router.push('/dashboard/partnerships')}>
                <Handshake className="mr-2 h-4 w-4" />
                <span>Partnerships</span>
            </DropdownMenuItem>
        </DropdownMenuGroup>
        
        <DropdownMenuSeparator />

        <DropdownMenuGroup>
             <DropdownMenuLabel className="text-xs text-muted-foreground">Account & Rewards</DropdownMenuLabel>
              <DropdownMenuItem>
                <TrendingUp className="mr-2 h-4 w-4" />
                <span>My Level</span>
                <span className="ml-auto text-xs font-bold">Level {userLevel}</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push('/dashboard/gift-box')}>
                <Star className="mr-2 h-4 w-4" />
                <span>My Points</span>
                <span className="ml-auto text-xs text-muted-foreground">{userPoints} pts</span>
              </DropdownMenuItem>
        </DropdownMenuGroup>
       
        <DropdownMenuSeparator />
        
         <DropdownMenuGroup>
              <DropdownMenuItem onClick={() => router.push('/dashboard/premium')} >
                <Sparkles className="mr-2 h-4 w-4 text-amber-500" />
                <span>Become a Premium Member</span>
              </DropdownMenuItem>
        </DropdownMenuGroup>

        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleSignOut}>
          Log out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
